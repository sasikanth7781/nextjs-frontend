const AppConstant = {
    EMAIL_IS_REQUIRED:'Email is required.',
    VALID_EMAIL_ADDRESS:'Email must be a valid email address.',
    PASSWORD_REQUIRED:'Password is required.',
    EMPTY_STRING:'',
    SUCCESS:'Success',
    TOKEN:'token',
    ACTIVE: "Active",
    INACTIVE: "Inactive"
};

export default AppConstant;