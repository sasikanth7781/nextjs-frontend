"use client";
import { redirect } from "next/navigation";
// import { userStore } from "src/store/userStore";

// import { getCookie } from "cookies-next";

export default function HomePage() {
  //   const { user, setUserStore } = userStore((state) => ({
  //     user: state.user,
  //     setUserStore: state.setUserStore,
  //   }));

  //   let userInfo = getCookie("userInfo");
  //   let userData: any = null;

  //   if(userInfo)
  //     {
  //       userData = JSON.parse(userInfo);
  //     }

  //   if(userData && userData.isLoggedIn)
  //     {
  //       redirect('/dashboard');
  //     }
  //   else
  //     {
  //    redirect('auth/login');
  // }
  redirect("auth/login");
}
