import axios, { AxiosError, AxiosResponse } from "axios";
import secureLocalStorage from "react-secure-storage";
import AppConstant from "../app/constant/AppConstant";

const getAuthToken = (): string | null => {
  let decodedTokenData: string | null = null;
  const token = secureLocalStorage.getItem(AppConstant.TOKEN)?.toString();
  if (!!token) {
    decodedTokenData = token;
  }

  return decodedTokenData;
};

export const ENDPIONTS = {
  LOGIN: "Login",
};

interface TypeCallbackFn {
  (data: object | null): void;
}

// Define the type for the returned API methods object
interface ApiMethods {
  fetchAll: () => Promise<AxiosResponse<unknown>>;
  fetchById: (id: string) => Promise<AxiosResponse<unknown>>;
  create: (newRecord: object) => Promise<AxiosResponse<unknown>>;
  update: (
    id: string,
    updatedRecord: object
  ) => Promise<AxiosResponse<unknown>>;
  delete: (id: string) => Promise<AxiosResponse<unknown>>;
  fetchData: (id: string) => Promise<AxiosResponse<unknown>>;
  searchData: (searchCriteria: object) => Promise<AxiosResponse<unknown>>;
  fetchByUserId: (userId: string) => Promise<AxiosResponse<unknown>>;
  fetchFileById: (id: string) => Promise<AxiosResponse<unknown>>;
  fetchFileByParam: (param: object) => Promise<AxiosResponse<unknown>>;
  fetchFile: () => Promise<AxiosResponse<unknown>>;
}

export const CCSCAPIEndpoint = (endpoint: string): object => {
  const url = process.env.NEXT_PUBLIC_API_URL + endpoint + "/";
  const token = getAuthToken();
  const headers = {
    "Content-Type": "application/json",
    Authorization: "Bearer " + "" + token,
  };

  return {
    fetchAll: () => axios.get(url, { headers: headers }),
    fetchById: (id: string) => axios.get(url + id, { headers: headers }),
    create: (newRecord: object) =>
      axios.post(url, newRecord, { headers: headers }),
    update: (id: string, updatedRecord: object) =>
      axios.put(url + id, updatedRecord, { headers: headers }),
    delete: (id: string) => axios.delete(url + id, { headers: headers }),
  };
};

export const CCSCAPIEndpointAndMehtod = (
  endpoint: string,
  methodName: string | null
): ApiMethods => {
  const url = !!methodName
    ? process.env.NEXT_PUBLIC_API_URL + endpoint + "/" + methodName
    : process.env.NEXT_PUBLIC_API_URL + endpoint + "/";

  const token = getAuthToken();
  const headers = {
    "Content-Type": "application/json",
    Authorization: "Bearer " + "" + token,
  };
  return {
    fetchAll: () => axios.get(url, { headers: headers }),
    fetchById: (id: string) => axios.get(url + id, { headers: headers }),
    fetchByUserId: (userId: string) =>
      axios.get(`${url}?userId=${userId}`, { headers }),
    create: (newRecord: object) =>
      axios.post(url, newRecord, { headers: headers }),
    update: (id: string, updatedRecord: object) =>
      axios.put(url + id, updatedRecord, { headers: headers }),
    delete: (id: string) => axios.delete(url + id, { headers: headers }),
    fetchData: (id: string) => axios.get(url, { headers: headers, params: id }),
    fetchFileById: (id: string) =>
      axios.get(url + id, { headers: headers, responseType: "blob" }),
    fetchFileByParam: (param: object) =>
      axios.get(url, { headers: headers, params: param, responseType: "blob" }),
    fetchFile: () => axios.get(url, { headers: headers, responseType: "blob" }),
    searchData: (searchCriteria: object) =>
      axios.get(url, { headers: headers, params: searchCriteria }),
  };
};

export const callGetApiWithData = (
  endpoint: string,
  methodName: string | null,
  data: object,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .searchData(data)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};

const onResponse = (response: AxiosResponse): AxiosResponse => {
  return response;
};

const onResponseError = (error: AxiosError): Promise<AxiosError> => {
  if (
    error?.response?.status == 401 &&
    window.location.pathname != "/auth/login"
  ) {
    secureLocalStorage.clear();
    localStorage.clear();
    secureLocalStorage.removeItem(AppConstant.TOKEN);
    window.location.href = "/auth/login";
  }
  return Promise.reject(error);
};

axios.interceptors.response.use(onResponse, onResponseError);

export const callPostApiWithData = (
  endpoint: string,
  methodName: string | null,
  data: object,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .create(data)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};

export const callDeleteApiWithData = (
  endpoint: string,
  methodName: string | null,
  id: string,
  onSuccess: TypeCallbackFn,
  onError: TypeCallbackFn
): void => {
  CCSCAPIEndpointAndMehtod(endpoint, methodName)
    .delete(id)
    .then((response) => {
      onSuccess(response.data as object);
    })
    .catch((err) => onError(err));
};

export const MultiPartAPIEndpointAndMethod = (
  endpoint: string,
  methodName: string
) => {
  const url = !!methodName
    ? process.env.NEXT_PUBLIC_API_URL + endpoint + "/" + methodName
    : process.env.NEXT_PUBLIC_API_URL + endpoint + "/";

  const token = getAuthToken();
  const headers = {
    "Content-Type": "multipart/form-data",
    Authorization: "Bearer " + "" + token,
  };

  return {
    fetchAll: () => axios.get(url, { headers: headers }),
    fetchById: (id: string) => axios.get(url + "/" + id, { headers: headers }),
    create: (newRecord: object) =>
      axios.post(url, newRecord, { headers: headers }),
    update: (id: string, updatedRecord: object) =>
      axios.put(url + id, updatedRecord, { headers: headers }),
    delete: (id: string) => axios.delete(url + "/" + id, { headers: headers }),
    fetchData: (id: string) => axios.get(url, { headers: headers, params: id }),
    searchData: (searchCriteria: object) =>
      axios.get(url, { headers: headers, params: searchCriteria }),
  };
};
