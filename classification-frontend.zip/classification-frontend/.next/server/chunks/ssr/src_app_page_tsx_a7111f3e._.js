module.exports = [
"[project]/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"use client";
;
function HomePage() {
    //   const { user, setUserStore } = userStore((state) => ({
    //     user: state.user,
    //     setUserStore: state.setUserStore,
    //   }));
    //   let userInfo = getCookie("userInfo");
    //   let userData: any = null;
    //   if(userInfo)
    //     {
    //       userData = JSON.parse(userInfo);
    //     }
    //   if(userData && userData.isLoggedIn)
    //     {
    //       redirect('/dashboard');
    //     }
    //   else
    //     {
    //    redirect('auth/login');
    // }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["redirect"])("auth/login");
}
}),
];

//# sourceMappingURL=src_app_page_tsx_a7111f3e._.js.map