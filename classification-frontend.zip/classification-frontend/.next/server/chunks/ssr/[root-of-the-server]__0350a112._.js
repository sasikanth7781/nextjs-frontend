module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/theme/palette.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "action",
    ()=>action,
    "common",
    ()=>common,
    "error",
    ()=>error,
    "grey",
    ()=>grey,
    "info",
    ()=>info,
    "palette",
    ()=>palette,
    "primary",
    ()=>primary,
    "secondary",
    ()=>secondary,
    "success",
    ()=>success,
    "warning",
    ()=>warning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
;
const grey = {
    0: "#FFFFFF",
    100: "#F9FAFB",
    200: "#F4F6F8",
    300: "#DFE3E8",
    400: "#C4CDD5",
    500: "#919EAB",
    600: "#637381",
    700: "#454F5B",
    800: "#212B36",
    900: "#161C24"
};
const primary = {
    lighter: "#C8FAD6",
    light: "#5BE49B",
    main: "#00A76F",
    dark: "#007867",
    darker: "#004B50",
    contrastText: "#FFFFFF"
};
const secondary = {
    lighter: "#EFD6FF",
    light: "#C684FF",
    main: "#8E33FF",
    dark: "#5119B7",
    darker: "#27097A",
    contrastText: "#FFFFFF"
};
const info = {
    lighter: "#CAFDF5",
    light: "#61F3F3",
    main: "#00B8D9",
    dark: "#006C9C",
    darker: "#003768",
    contrastText: "#FFFFFF"
};
const success = {
    lighter: "#D3FCD2",
    light: "#77ED8B",
    main: "#22C55E",
    dark: "#118D57",
    darker: "#065E49",
    contrastText: "#ffffff"
};
const warning = {
    lighter: "#FFF5CC",
    light: "#FFD666",
    main: "#FFAB00",
    dark: "#B76E00",
    darker: "#7A4100",
    contrastText: grey[800]
};
const error = {
    lighter: "#FFE9D5",
    light: "#FFAC82",
    main: "#FF5630",
    dark: "#B71D18",
    darker: "#7A0916",
    contrastText: "#FFFFFF"
};
const common = {
    black: "#000000",
    white: "#FFFFFF"
};
const action = {
    hover: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.08),
    selected: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.16),
    disabled: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.8),
    disabledBackground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.24),
    focus: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.24),
    hoverOpacity: 0.08,
    disabledOpacity: 0.48
};
const base = {
    primary,
    secondary,
    info,
    success,
    warning,
    error,
    grey,
    common,
    divider: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.2),
    action
};
function palette(mode) {
    const light = {
        ...base,
        mode: "light",
        text: {
            primary: grey[800],
            secondary: grey[600],
            disabled: grey[500]
        },
        background: {
            paper: "#FFFFFF",
            default: "#FFFFFF",
            neutral: grey[200]
        },
        action: {
            ...base.action,
            active: grey[600]
        }
    };
    const dark = {
        ...base,
        mode: "dark",
        text: {
            primary: "#FFFFFF",
            secondary: grey[500],
            disabled: grey[600]
        },
        background: {
            paper: grey[800],
            default: grey[900],
            neutral: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(grey[500], 0.12)
        },
        action: {
            ...base.action,
            active: grey[500]
        }
    };
    return mode === "light" ? light : dark;
}
}),
"[project]/src/theme/shadows.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "shadows",
    ()=>shadows
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/palette.ts [app-ssr] (ecmascript)");
;
;
function shadows(mode) {
    const color = mode === "light" ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["grey"][500] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["common"].black;
    const transparent1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.2);
    const transparent2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.14);
    const transparent3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.12);
    return [
        "none",
        `0px 2px 1px -1px ${transparent1},0px 1px 1px 0px ${transparent2},0px 1px 3px 0px ${transparent3}`,
        `0px 3px 1px -2px ${transparent1},0px 2px 2px 0px ${transparent2},0px 1px 5px 0px ${transparent3}`,
        `0px 3px 3px -2px ${transparent1},0px 3px 4px 0px ${transparent2},0px 1px 8px 0px ${transparent3}`,
        `0px 2px 4px -1px ${transparent1},0px 4px 5px 0px ${transparent2},0px 1px 10px 0px ${transparent3}`,
        `0px 3px 5px -1px ${transparent1},0px 5px 8px 0px ${transparent2},0px 1px 14px 0px ${transparent3}`,
        `0px 3px 5px -1px ${transparent1},0px 6px 10px 0px ${transparent2},0px 1px 18px 0px ${transparent3}`,
        `0px 4px 5px -2px ${transparent1},0px 7px 10px 1px ${transparent2},0px 2px 16px 1px ${transparent3}`,
        `0px 5px 5px -3px ${transparent1},0px 8px 10px 1px ${transparent2},0px 3px 14px 2px ${transparent3}`,
        `0px 5px 6px -3px ${transparent1},0px 9px 12px 1px ${transparent2},0px 3px 16px 2px ${transparent3}`,
        `0px 6px 6px -3px ${transparent1},0px 10px 14px 1px ${transparent2},0px 4px 18px 3px ${transparent3}`,
        `0px 6px 7px -4px ${transparent1},0px 11px 15px 1px ${transparent2},0px 4px 20px 3px ${transparent3}`,
        `0px 7px 8px -4px ${transparent1},0px 12px 17px 2px ${transparent2},0px 5px 22px 4px ${transparent3}`,
        `0px 7px 8px -4px ${transparent1},0px 13px 19px 2px ${transparent2},0px 5px 24px 4px ${transparent3}`,
        `0px 7px 9px -4px ${transparent1},0px 14px 21px 2px ${transparent2},0px 5px 26px 4px ${transparent3}`,
        `0px 8px 9px -5px ${transparent1},0px 15px 22px 2px ${transparent2},0px 6px 28px 5px ${transparent3}`,
        `0px 8px 10px -5px ${transparent1},0px 16px 24px 2px ${transparent2},0px 6px 30px 5px ${transparent3}`,
        `0px 8px 11px -5px ${transparent1},0px 17px 26px 2px ${transparent2},0px 6px 32px 5px ${transparent3}`,
        `0px 9px 11px -5px ${transparent1},0px 18px 28px 2px ${transparent2},0px 7px 34px 6px ${transparent3}`,
        `0px 9px 12px -6px ${transparent1},0px 19px 29px 2px ${transparent2},0px 7px 36px 6px ${transparent3}`,
        `0px 10px 13px -6px ${transparent1},0px 20px 31px 3px ${transparent2},0px 8px 38px 7px ${transparent3}`,
        `0px 10px 13px -6px ${transparent1},0px 21px 33px 3px ${transparent2},0px 8px 40px 7px ${transparent3}`,
        `0px 10px 14px -6px ${transparent1},0px 22px 35px 3px ${transparent2},0px 8px 42px 7px ${transparent3}`,
        `0px 11px 14px -7px ${transparent1},0px 23px 36px 3px ${transparent2},0px 9px 44px 8px ${transparent3}`,
        `0px 11px 15px -7px ${transparent1},0px 24px 38px 3px ${transparent2},0px 9px 46px 8px ${transparent3}`
    ];
}
}),
"[next]/internal/font/google/public_sans_99cb125d.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "public_sans_99cb125d-module__0EKqFa__className",
});
}),
"[next]/internal/font/google/public_sans_99cb125d.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$public_sans_99cb125d$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/public_sans_99cb125d.module.css [app-ssr] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$public_sans_99cb125d$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Public Sans', Helvetica, Arial, sans-serif",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$public_sans_99cb125d$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$public_sans_99cb125d$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[next]/internal/font/google/barlow_c1b94d2f.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "barlow_c1b94d2f-module__LhAfyq__className",
});
}),
"[next]/internal/font/google/barlow_c1b94d2f.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$barlow_c1b94d2f$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/barlow_c1b94d2f.module.css [app-ssr] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$barlow_c1b94d2f$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Barlow', Helvetica, Arial, sans-serif",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$barlow_c1b94d2f$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$barlow_c1b94d2f$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[project]/src/theme/typography.ts [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pxToRem",
    ()=>pxToRem,
    "remToPx",
    ()=>remToPx,
    "responsiveFontSizes",
    ()=>responsiveFontSizes,
    "typography",
    ()=>typography
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$public_sans_99cb125d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/public_sans_99cb125d.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$barlow_c1b94d2f$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/barlow_c1b94d2f.js [app-ssr] (ecmascript)");
;
;
function remToPx(value) {
    return Math.round(parseFloat(value) * 16);
}
function pxToRem(value) {
    return `${value / 16}rem`;
}
function responsiveFontSizes({ sm, md, lg }) {
    return {
        "@media (min-width:600px)": {
            fontSize: pxToRem(sm)
        },
        "@media (min-width:900px)": {
            fontSize: pxToRem(md)
        },
        "@media (min-width:1200px)": {
            fontSize: pxToRem(lg)
        }
    };
}
const typography = {
    fontFamily: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$public_sans_99cb125d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].style.fontFamily,
    fontSecondaryFamily: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$barlow_c1b94d2f$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].style.fontFamily,
    fontWeightRegular: 400,
    fontWeightMedium: 500,
    fontWeightSemiBold: 600,
    fontWeightBold: 700,
    h1: {
        fontWeight: 800,
        lineHeight: 80 / 64,
        fontSize: pxToRem(40),
        ...responsiveFontSizes({
            sm: 52,
            md: 58,
            lg: 64
        })
    },
    h2: {
        fontWeight: 800,
        lineHeight: 64 / 48,
        fontSize: pxToRem(32),
        ...responsiveFontSizes({
            sm: 40,
            md: 44,
            lg: 48
        })
    },
    h3: {
        fontWeight: 700,
        lineHeight: 1.5,
        fontSize: pxToRem(24),
        ...responsiveFontSizes({
            sm: 26,
            md: 30,
            lg: 32
        })
    },
    h4: {
        fontWeight: 700,
        lineHeight: 1.5,
        fontSize: pxToRem(20),
        ...responsiveFontSizes({
            sm: 20,
            md: 24,
            lg: 24
        })
    },
    h5: {
        fontWeight: 700,
        lineHeight: 1.5,
        fontSize: pxToRem(18),
        ...responsiveFontSizes({
            sm: 19,
            md: 20,
            lg: 20
        })
    },
    h6: {
        fontWeight: 700,
        lineHeight: 28 / 18,
        fontSize: pxToRem(17),
        ...responsiveFontSizes({
            sm: 18,
            md: 18,
            lg: 18
        })
    },
    subtitle1: {
        fontWeight: 600,
        lineHeight: 1.5,
        fontSize: pxToRem(16)
    },
    subtitle2: {
        fontWeight: 600,
        lineHeight: 22 / 14,
        fontSize: pxToRem(14)
    },
    body1: {
        lineHeight: 1.5,
        fontSize: pxToRem(16)
    },
    body2: {
        lineHeight: 22 / 14,
        fontSize: pxToRem(14)
    },
    caption: {
        lineHeight: 1.5,
        fontSize: pxToRem(12)
    },
    overline: {
        fontWeight: 700,
        lineHeight: 1.5,
        fontSize: pxToRem(12),
        textTransform: "uppercase"
    },
    button: {
        fontWeight: 700,
        lineHeight: 24 / 14,
        fontSize: pxToRem(14),
        textTransform: "unset"
    }
};
;
;
}),
"[project]/src/theme/custom-shadows.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "customShadows",
    ()=>customShadows
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/palette.ts [app-ssr] (ecmascript)");
;
;
function customShadows(mode) {
    const color = mode === "light" ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["grey"][500] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["common"].black;
    const transparent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.16);
    return {
        z1: `0 1px 2px 0 ${transparent}`,
        z4: `0 4px 8px 0 ${transparent}`,
        z8: `0 8px 16px 0 ${transparent}`,
        z12: `0 12px 24px -4px ${transparent}`,
        z16: `0 16px 32px -4px ${transparent}`,
        z20: `0 20px 40px -4px ${transparent}`,
        z24: `0 24px 48px 0 ${transparent}`,
        //
        card: `0 0 2px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.2)}, 0 12px 24px -4px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.12)}`,
        dropdown: `0 0 2px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.24)}, -20px 20px 40px -4px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(color, 0.24)}`,
        dialog: `-40px 40px 80px -8px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["common"].black, 0.24)}`,
        //
        primary: `0 8px 16px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["primary"].main, 0.24)}`,
        info: `0 8px 16px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["info"].main, 0.24)}`,
        secondary: `0 8px 16px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["secondary"].main, 0.24)}`,
        success: `0 8px 16px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["success"].main, 0.24)}`,
        warning: `0 8px 16px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["warning"].main, 0.24)}`,
        error: `0 8px 16px 0 ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["error"].main, 0.24)}`
    };
}
}),
"[project]/src/theme/overrides/components/fab.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fab",
    ()=>fab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Fab$2f$fabClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fabClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Fab/fabClasses.js [app-ssr] (ecmascript) <export default as fabClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function fab(theme) {
    const lightMode = theme.palette.mode === 'light';
    const rootStyles = (ownerState)=>{
        const defaultColor = ownerState.color === 'default';
        const inheritColor = ownerState.color === 'inherit';
        const circularVariant = ownerState.variant === 'circular';
        const extendedVariant = ownerState.variant === 'extended';
        const outlinedVariant = ownerState.variant === 'outlined';
        const outlinedExtendedVariant = ownerState.variant === 'outlinedExtended';
        const softVariant = ownerState.variant === 'soft';
        const softExtendedVariant = ownerState.variant === 'softExtended';
        const defaultStyle = {
            '&:hover, &:active': {
                boxShadow: 'none'
            },
            // FILLED
            ...(circularVariant || extendedVariant) && {
                ...(defaultColor || inheritColor) && {
                    boxShadow: theme.customShadows.z8
                },
                ...inheritColor && {
                    backgroundColor: theme.palette.text.primary,
                    color: lightMode ? theme.palette.common.white : theme.palette.grey[800],
                    '&:hover': {
                        backgroundColor: lightMode ? theme.palette.grey[700] : theme.palette.grey[400]
                    }
                }
            },
            // OUTLINED
            ...(outlinedVariant || outlinedExtendedVariant) && {
                boxShadow: 'none',
                backgroundColor: 'transparent',
                ...(defaultColor || inheritColor) && {
                    border: `solid 1px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.32)}`
                },
                ...defaultColor && {
                    ...!lightMode && {
                        color: theme.palette.text.secondary
                    }
                },
                '&:hover': {
                    borderColor: 'currentColor',
                    boxShadow: '0 0 0 0.5px currentColor',
                    backgroundColor: theme.palette.action.hover
                }
            },
            // SOFT
            ...(softVariant || softExtendedVariant) && {
                boxShadow: 'none',
                ...defaultColor && {
                    color: theme.palette.grey[800],
                    backgroundColor: theme.palette.grey[300],
                    '&:hover': {
                        backgroundColor: theme.palette.grey[400]
                    }
                },
                ...inheritColor && {
                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.08),
                    '&:hover': {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.24)
                    }
                }
            }
        };
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.color === color && {
                    // FILLED
                    ...(circularVariant || extendedVariant) && {
                        boxShadow: theme.customShadows[color],
                        '&:hover': {
                            backgroundColor: theme.palette[color].dark
                        }
                    },
                    // OUTLINED
                    ...(outlinedVariant || outlinedExtendedVariant) && {
                        color: theme.palette[color].main,
                        border: `solid 1px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.48)}`,
                        '&:hover': {
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.08)
                        }
                    },
                    // SOFT
                    ...(softVariant || softExtendedVariant) && {
                        color: theme.palette[color][lightMode ? 'dark' : 'light'],
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.16),
                        '&:hover': {
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.32)
                        }
                    }
                }
            }));
        const disabledState = {
            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Fab$2f$fabClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fabClasses$3e$__["fabClasses"].disabled}`]: {
                ...(outlinedVariant || outlinedExtendedVariant) && {
                    backgroundColor: 'transparent',
                    border: `solid 1px ${theme.palette.action.disabledBackground}`
                }
            }
        };
        const size = {
            ...(extendedVariant || outlinedExtendedVariant || softExtendedVariant) && {
                width: 'auto',
                '& svg': {
                    marginRight: theme.spacing(1)
                },
                ...ownerState.size === 'small' && {
                    height: 34,
                    minHeight: 34,
                    borderRadius: 17,
                    padding: theme.spacing(0, 1)
                },
                ...ownerState.size === 'medium' && {
                    height: 40,
                    minHeight: 40,
                    borderRadius: 20,
                    padding: theme.spacing(0, 2)
                },
                ...ownerState.size === 'large' && {
                    height: 48,
                    minHeight: 48,
                    borderRadius: 24,
                    padding: theme.spacing(0, 2)
                }
            }
        };
        return [
            defaultStyle,
            ...colorStyle,
            disabledState,
            size
        ];
    };
    return {
        MuiFab: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/card.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "card",
    ()=>card
]);
function card(theme) {
    return {
        MuiCard: {
            styleOverrides: {
                root: {
                    position: 'relative',
                    boxShadow: theme.customShadows.card,
                    borderRadius: theme.shape.borderRadius * 2,
                    zIndex: 0
                }
            }
        },
        MuiCardHeader: {
            styleOverrides: {
                root: {
                    padding: theme.spacing(3, 3, 0)
                }
            }
        },
        MuiCardContent: {
            styleOverrides: {
                root: {
                    padding: theme.spacing(3)
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/chip.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "chip",
    ()=>chip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/chipClasses.js [app-ssr] (ecmascript) <export default as chipClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function chip(theme) {
    const lightMode = theme.palette.mode === 'light';
    const rootStyles = (ownerState)=>{
        const defaultColor = ownerState.color === 'default';
        const filledVariant = ownerState.variant === 'filled';
        const outlinedVariant = ownerState.variant === 'outlined';
        const softVariant = ownerState.variant === 'soft';
        const defaultStyle = {
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].deleteIcon}`]: {
                opacity: 0.48,
                color: 'currentColor',
                '&:hover': {
                    opacity: 1,
                    color: 'currentColor'
                }
            },
            ...defaultColor && {
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].avatar}`]: {
                    color: theme.palette.text.primary
                },
                // FILLED
                ...filledVariant && {
                    color: lightMode ? theme.palette.common.white : theme.palette.grey[800],
                    backgroundColor: theme.palette.text.primary,
                    '&:hover': {
                        backgroundColor: lightMode ? theme.palette.grey[700] : theme.palette.grey[100]
                    },
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].icon}`]: {
                        color: lightMode ? theme.palette.common.white : theme.palette.grey[800]
                    }
                },
                // OUTLINED
                ...outlinedVariant && {
                    border: `solid 1px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.32)}`
                },
                // SOFT
                ...softVariant && {
                    color: theme.palette.text.primary,
                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.16),
                    '&:hover': {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.32)
                    }
                }
            }
        };
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.color === color && {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].avatar}`]: {
                        color: theme.palette[color].lighter,
                        backgroundColor: theme.palette[color].dark
                    },
                    // SOFT
                    ...softVariant && {
                        color: theme.palette[color][lightMode ? 'dark' : 'light'],
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.16),
                        '&:hover': {
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.32)
                        }
                    }
                }
            }));
        const disabledState = {
            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].disabled}`]: {
                opacity: 1,
                color: theme.palette.action.disabled,
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].icon}`]: {
                    color: theme.palette.action.disabled
                },
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$chipClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__chipClasses$3e$__["chipClasses"].avatar}`]: {
                    color: theme.palette.action.disabled,
                    backgroundColor: theme.palette.action.disabledBackground
                },
                // FILLED
                ...filledVariant && {
                    backgroundColor: theme.palette.action.disabledBackground
                },
                // OUTLINED
                ...outlinedVariant && {
                    borderColor: theme.palette.action.disabledBackground
                },
                // SOFT
                ...softVariant && {
                    backgroundColor: theme.palette.action.disabledBackground
                }
            }
        };
        return [
            defaultStyle,
            ...colorStyle,
            disabledState,
            {
                fontWeight: 500,
                borderRadius: theme.shape.borderRadius
            }
        ];
    };
    return {
        MuiChip: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/tabs.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tabs",
    ()=>tabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$tabClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__tabClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/tabClasses.js [app-ssr] (ecmascript) <export default as tabClasses>");
;
function tabs(theme) {
    return {
        MuiTabs: {
            styleOverrides: {
                indicator: {
                    backgroundColor: theme.palette.text.primary
                },
                scrollButtons: {
                    width: 48,
                    borderRadius: '50%'
                }
            }
        },
        MuiTab: {
            styleOverrides: {
                root: {
                    padding: 0,
                    opacity: 1,
                    minWidth: 48,
                    minHeight: 48,
                    fontWeight: theme.typography.fontWeightSemiBold,
                    '&:not(:last-of-type)': {
                        marginRight: theme.spacing(3),
                        [theme.breakpoints.up('sm')]: {
                            marginRight: theme.spacing(5)
                        }
                    },
                    [`&:not(.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$tabClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__tabClasses$3e$__["tabClasses"].selected})`]: {
                        color: theme.palette.text.secondary
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/css.ts [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

// import { alpha, Theme } from "@mui/material/styles";
// import { dividerClasses } from "@mui/material/Divider";
// import { checkboxClasses } from "@mui/material/Checkbox";
// import { menuItemClasses } from "@mui/material/MenuItem";
// import { autocompleteClasses } from "@mui/material/Autocomplete";
// // ----------------------------------------------------------------------
// export const paper = ({
//   theme,
//   bgcolor,
//   dropdown,
// }: {
//   theme: Theme;
//   bgcolor?: string;
//   dropdown?: boolean;
// }) => ({
//   ...bgBlur({
//     blur: 20,
//     opacity: 0.9,
//     color: theme.palette.background.paper,
//     ...(!!bgcolor && {
//       color: bgcolor,
//     }),
//   }),
//   backgroundImage: "url(/assets/cyan-blur.png), url(/assets/red-blur.png)",
//   backgroundRepeat: "no-repeat, no-repeat",
//   backgroundPosition: "top right, left bottom",
//   backgroundSize: "50%, 50%",
//   ...(theme.direction === "rtl" && {
//     backgroundPosition: "top left, right bottom",
//   }),
//   ...(dropdown && {
//     padding: theme.spacing(0.5),
//     boxShadow: theme.customShadows.dropdown,
//     borderRadius:
//       typeof theme.shape.borderRadius === "number"
//         ? theme.shape.borderRadius * 1.25
//         : `calc(${theme.shape.borderRadius} * 1.25)`,
//   }),
// });
// // ----------------------------------------------------------------------
// export const menuItem = (theme: Theme) => ({
//   ...theme.typography.body2,
//   padding: theme.spacing(0.75, 1),
//   borderRadius:
//     typeof theme.shape.borderRadius === "number"
//       ? theme.shape.borderRadius * 0.75
//       : `calc(${theme.shape.borderRadius} * 0.75)`,
//   "&:not(:last-of-type)": {
//     // marginBottom: 4,
//   },
//   [`&.${menuItemClasses.selected}`]: {
//     fontWeight: theme.typography.fontWeightSemiBold,
//     backgroundColor: theme.palette.action.selected,
//     "&:hover": {
//       backgroundColor: theme.palette.action.hover,
//     },
//   },
//   [`& .${checkboxClasses.root}`]: {
//     padding: theme.spacing(0.5),
//     marginLeft: theme.spacing(-0.5),
//     marginRight: theme.spacing(0.5),
//   },
//   [`&.${autocompleteClasses.option}[aria-selected="true"]`]: {
//     backgroundColor: theme.palette.action.selected,
//     "&:hover": {
//       backgroundColor: theme.palette.action.hover,
//     },
//   },
//   [`&+.${dividerClasses.root}`]: {
//     margin: theme.spacing(0.5, 0),
//   },
// });
// // ----------------------------------------------------------------------
// type BgBlurProps = {
//   blur?: number;
//   opacity?: number;
//   color?: string;
//   imgUrl?: string;
// };
// export function bgBlur(props?: BgBlurProps) {
//   const color = props?.color || "#000000";
//   const blur = props?.blur || 6;
//   const opacity = props?.opacity || 0.8;
//   const imgUrl = props?.imgUrl;
//   if (imgUrl) {
//     return {
//       position: "relative",
//       backgroundImage: `url(${imgUrl})`,
//       "&:before": {
//         position: "absolute",
//         top: 0,
//         left: 0,
//         zIndex: 9,
//         content: '""',
//         width: "100%",
//         height: "100%",
//         backdropFilter: `blur(${blur}px)`,
//         WebkitBackdropFilter: `blur(${blur}px)`,
//         backgroundColor: alpha(color, opacity),
//       },
//     } as const;
//   }
//   return {
//     backdropFilter: `blur(${blur}px)`,
//     WebkitBackdropFilter: `blur(${blur}px)`,
//     backgroundColor: alpha(color, opacity),
//   };
// }
// // ----------------------------------------------------------------------
// type BgGradientProps = {
//   direction?: string;
//   color?: string;
//   startColor?: string;
//   endColor?: string;
//   imgUrl?: string;
// };
// export function bgGradient(props?: BgGradientProps) {
//   const direction = props?.direction || "to bottom";
//   const startColor = props?.startColor;
//   const endColor = props?.endColor;
//   const imgUrl = props?.imgUrl;
//   const color = props?.color;
//   if (imgUrl) {
//     return {
//       background: `linear-gradient(${direction}, ${startColor || color}, ${
//         endColor || color
//       }), url(${imgUrl})`,
//       backgroundSize: "cover",
//       backgroundRepeat: "no-repeat",
//       backgroundPosition: "center center",
//     };
//   }
//   return {
//     background: `linear-gradient(${direction}, ${startColor}, ${endColor})`,
//   };
// }
// // ----------------------------------------------------------------------
// export function textGradient(value: string) {
//   return {
//     background: `-webkit-linear-gradient(${value})`,
//     WebkitBackgroundClip: "text",
//     WebkitTextFillColor: "transparent",
//   };
// }
// // ----------------------------------------------------------------------
// export const hideScroll = {
//   x: {
//     msOverflowStyle: "none",
//     scrollbarWidth: "none",
//     overflowX: "scroll",
//     "&::-webkit-scrollbar": {
//       display: "none",
//     },
//   },
//   y: {
//     msOverflowStyle: "none",
//     scrollbarWidth: "none",
//     overflowY: "scroll",
//     "&::-webkit-scrollbar": {
//       display: "none",
//     },
//   },
// } as const;
}),
"[project]/src/theme/overrides/components/menu.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "menu",
    ()=>menu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/css.ts [app-ssr] (ecmascript)");
;
function menu(theme) {
    return {
        MuiMenuItem: {
            styleOverrides: {
                root: {
                    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["menuItem"])(theme)
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/list.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "list",
    ()=>list
]);
function list(theme) {
    return {
        MuiListItemIcon: {
            styleOverrides: {
                root: {
                    color: 'inherit',
                    minWidth: 'auto',
                    marginRight: theme.spacing(2)
                }
            }
        },
        MuiListItemAvatar: {
            styleOverrides: {
                root: {
                    minWidth: 'auto',
                    marginRight: theme.spacing(2)
                }
            }
        },
        MuiListItemText: {
            styleOverrides: {
                root: {
                    margin: 0
                },
                multiline: {
                    margin: 0
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/table.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "table",
    ()=>table
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$tableRowClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__tableRowClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableRow/tableRowClasses.js [app-ssr] (ecmascript) <export default as tableRowClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$tableCellClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__tableCellClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableCell/tableCellClasses.js [app-ssr] (ecmascript) <export default as tableCellClasses>");
;
;
;
function table(theme) {
    return {
        MuiTableContainer: {
            styleOverrides: {
                root: {
                    position: 'relative'
                }
            }
        },
        MuiTableRow: {
            styleOverrides: {
                root: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$tableRowClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__tableRowClasses$3e$__["tableRowClasses"].selected}`]: {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.primary.dark, 0.04),
                        '&:hover': {
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.primary.dark, 0.08)
                        }
                    },
                    '&:last-of-type': {
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$tableCellClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__tableCellClasses$3e$__["tableCellClasses"].root}`]: {
                            borderColor: 'transparent'
                        }
                    }
                }
            }
        },
        MuiTableCell: {
            styleOverrides: {
                root: {
                    borderBottomStyle: 'dashed'
                },
                head: {
                    fontSize: 14,
                    color: theme.palette.text.secondary,
                    fontWeight: theme.typography.fontWeightSemiBold,
                    backgroundColor: theme.palette.background.neutral
                },
                stickyHeader: {
                    backgroundColor: theme.palette.background.paper,
                    backgroundImage: `linear-gradient(to bottom, ${theme.palette.background.neutral} 0%, ${theme.palette.background.neutral} 100%)`
                },
                paddingCheckbox: {
                    paddingLeft: theme.spacing(1)
                }
            }
        },
        MuiTablePagination: {
            styleOverrides: {
                root: {
                    width: '100%'
                },
                toolbar: {
                    height: 64
                },
                actions: {
                    marginRight: 8
                },
                select: {
                    paddingLeft: 8,
                    '&:focus': {
                        borderRadius: theme.shape.borderRadius
                    }
                },
                selectIcon: {
                    right: 4,
                    width: 16,
                    height: 16,
                    top: 'calc(50% - 8px)'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/alert.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "alert",
    ()=>alert
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__alertClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/alertClasses.js [app-ssr] (ecmascript) <export default as alertClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'info',
    'success',
    'warning',
    'error'
];
function alert(theme) {
    const lightMode = theme.palette.mode === 'light';
    const rootStyles = (ownerState)=>{
        const standardVariant = ownerState.variant === 'standard';
        const filledVariant = ownerState.variant === 'filled';
        const outlinedVariant = ownerState.variant === 'outlined';
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.severity === color && {
                    // STANDARD
                    ...standardVariant && {
                        color: theme.palette[color][lightMode ? 'darker' : 'lighter'],
                        backgroundColor: theme.palette[color][lightMode ? 'lighter' : 'darker'],
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__alertClasses$3e$__["alertClasses"].icon}`]: {
                            color: theme.palette[color][lightMode ? 'main' : 'light']
                        }
                    },
                    // FILLED
                    ...filledVariant && {
                        color: theme.palette[color].contrastText,
                        backgroundColor: theme.palette[color].main
                    },
                    // OUTLINED
                    ...outlinedVariant && {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.08),
                        color: theme.palette[color][lightMode ? 'dark' : 'light'],
                        border: `solid 1px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.16)}`,
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$alertClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__alertClasses$3e$__["alertClasses"].icon}`]: {
                            color: theme.palette[color].main
                        }
                    }
                }
            }));
        return [
            ...colorStyle
        ];
    };
    return {
        MuiAlert: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState),
                icon: {
                    opacity: 1
                }
            }
        },
        MuiAlertTitle: {
            styleOverrides: {
                root: {
                    marginBottom: theme.spacing(0.5),
                    fontWeight: theme.typography.fontWeightSemiBold
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/badge.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "badge",
    ()=>badge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/badgeClasses.js [app-ssr] (ecmascript) <export default as badgeClasses>");
;
function badge(theme) {
    return {
        MuiBadge: {
            styleOverrides: {
                dot: {
                    borderRadius: '50%'
                },
                root: ({ ownerState })=>{
                    const alway = ownerState.variant === 'alway';
                    const online = ownerState.variant === 'online';
                    const busy = ownerState.variant === 'busy';
                    const offline = ownerState.variant === 'offline';
                    const invisible = ownerState.variant === 'invisible';
                    const baseStyles = {
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__["badgeClasses"].invisible}`]: {
                            transform: 'unset'
                        },
                        width: 10,
                        zIndex: 9,
                        padding: 0,
                        height: 10,
                        minWidth: 'auto',
                        '&:before, &:after': {
                            content: "''",
                            borderRadius: 1,
                            backgroundColor: theme.palette.common.white
                        }
                    };
                    return {
                        ...online && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__["badgeClasses"].badge}`]: {
                                ...baseStyles,
                                backgroundColor: theme.palette.success.main
                            }
                        },
                        ...busy && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__["badgeClasses"].badge}`]: {
                                ...baseStyles,
                                backgroundColor: theme.palette.error.main,
                                '&:before': {
                                    width: 6,
                                    height: 2
                                }
                            }
                        },
                        ...offline && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__["badgeClasses"].badge}`]: {
                                ...baseStyles,
                                backgroundColor: theme.palette.text.disabled,
                                '&:before': {
                                    width: 6,
                                    height: 6,
                                    borderRadius: '50%'
                                }
                            }
                        },
                        ...alway && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__["badgeClasses"].badge}`]: {
                                ...baseStyles,
                                backgroundColor: theme.palette.warning.main,
                                '&:before': {
                                    width: 2,
                                    height: 4,
                                    transform: 'translateX(1px) translateY(-1px)'
                                },
                                '&:after': {
                                    width: 2,
                                    height: 4,
                                    transform: 'translateY(1px) rotate(125deg)'
                                }
                            }
                        },
                        ...invisible && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$badgeClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__badgeClasses$3e$__["badgeClasses"].badge}`]: {
                                display: 'none'
                            }
                        }
                    };
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/paper.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "paper",
    ()=>paper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
;
function paper(theme) {
    return {
        MuiPaper: {
            styleOverrides: {
                root: {
                    backgroundImage: 'none'
                },
                outlined: {
                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.16)
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/radio.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "radio",
    ()=>radio
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Radio$2f$radioClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__radioClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Radio/radioClasses.js [app-ssr] (ecmascript) <export default as radioClasses>");
;
function radio(theme) {
    return {
        // CHECKBOX, RADIO, SWITCH
        MuiFormControlLabel: {
            styleOverrides: {
                label: {
                    ...theme.typography.body2
                }
            }
        },
        MuiRadio: {
            styleOverrides: {
                root: ({ ownerState })=>{
                    const { color } = ownerState;
                    return {
                        padding: theme.spacing(1),
                        ...color === 'default' && {
                            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Radio$2f$radioClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__radioClasses$3e$__["radioClasses"].checked}`]: {
                                color: theme.palette.text.primary
                            }
                        },
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Radio$2f$radioClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__radioClasses$3e$__["radioClasses"].disabled}`]: {
                            color: theme.palette.action.disabled
                        }
                    };
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/appbar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "appBar",
    ()=>appBar
]);
function appBar(theme) {
    return {
        MuiAppBar: {
            styleOverrides: {
                root: {
                    boxShadow: 'none'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/drawer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawer",
    ()=>drawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$drawerClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__drawerClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/drawerClasses.js [app-ssr] (ecmascript) <export default as drawerClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/css.ts [app-ssr] (ecmascript)");
;
;
;
function drawer(theme) {
    const lightMode = theme.palette.mode === 'light';
    return {
        MuiDrawer: {
            styleOverrides: {
                root: ({ ownerState })=>({
                        ...ownerState.variant === 'temporary' && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$drawerClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__drawerClasses$3e$__["drawerClasses"].paper}`]: {
                                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paper"])({
                                    theme
                                }),
                                ...ownerState.anchor === 'left' && {
                                    boxShadow: `40px 40px 80px -8px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(lightMode ? theme.palette.grey[500] : theme.palette.common.black, 0.24)}`
                                },
                                ...ownerState.anchor === 'right' && {
                                    boxShadow: `-40px 40px 80px -8px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(lightMode ? theme.palette.grey[500] : theme.palette.common.black, 0.24)}`
                                }
                            }
                        }
                    })
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/dialog.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dialog",
    ()=>dialog
]);
function dialog(theme) {
    return {
        MuiDialog: {
            styleOverrides: {
                paper: ({ ownerState })=>({
                        boxShadow: theme.customShadows.dialog,
                        borderRadius: theme.shape.borderRadius * 2,
                        ...!ownerState.fullScreen && {
                            margin: theme.spacing(2)
                        }
                    }),
                paperFullScreen: {
                    borderRadius: 0
                }
            }
        },
        MuiDialogTitle: {
            styleOverrides: {
                root: {
                    padding: theme.spacing(3)
                }
            }
        },
        MuiDialogContent: {
            styleOverrides: {
                root: {
                    padding: theme.spacing(0, 3)
                },
                dividers: {
                    borderTop: 0,
                    borderBottomStyle: 'dashed',
                    paddingBottom: theme.spacing(3)
                }
            }
        },
        MuiDialogActions: {
            styleOverrides: {
                root: {
                    padding: theme.spacing(3),
                    '& > :not(:first-of-type)': {
                        marginLeft: theme.spacing(1.5)
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/avatar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "avatar",
    ()=>avatar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$avatarGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__avatarGroupClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AvatarGroup/avatarGroupClasses.js [app-ssr] (ecmascript) <export default as avatarGroupClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'default',
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
const colorByName = (name)=>{
    const charAt = name.charAt(0).toLowerCase();
    if ([
        'a',
        'c',
        'f'
    ].includes(charAt)) return 'primary';
    if ([
        'e',
        'd',
        'h'
    ].includes(charAt)) return 'secondary';
    if ([
        'i',
        'k',
        'l'
    ].includes(charAt)) return 'info';
    if ([
        'm',
        'n',
        'p'
    ].includes(charAt)) return 'success';
    if ([
        'q',
        's',
        't'
    ].includes(charAt)) return 'warning';
    if ([
        'v',
        'x',
        'y'
    ].includes(charAt)) return 'error';
    return 'default';
};
function avatar(theme) {
    return {
        MuiAvatar: {
            variants: COLORS.map((color)=>color === 'default' ? {
                    props: {
                        color: 'default'
                    },
                    style: {
                        color: theme.palette.text.secondary,
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.24)
                    }
                } : {
                    props: {
                        color
                    },
                    style: {
                        color: theme.palette[color].contrastText,
                        backgroundColor: theme.palette[color].main
                    }
                }),
            styleOverrides: {
                rounded: {
                    borderRadius: theme.shape.borderRadius * 1.5
                },
                colorDefault: ({ ownerState })=>{
                    const color = colorByName(`${ownerState.alt}`);
                    return {
                        ...!!ownerState.alt && {
                            ...color !== 'default' ? {
                                color: theme.palette[color].contrastText,
                                backgroundColor: theme.palette[color].main
                            } : {
                                color: theme.palette.text.secondary,
                                backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.24)
                            }
                        }
                    };
                }
            }
        },
        MuiAvatarGroup: {
            styleOverrides: {
                root: ({ ownerState })=>({
                        justifyContent: 'flex-end',
                        ...ownerState.variant === 'compact' && {
                            width: 40,
                            height: 40,
                            position: 'relative',
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AvatarGroup$2f$avatarGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__avatarGroupClasses$3e$__["avatarGroupClasses"].avatar}`]: {
                                margin: 0,
                                width: 28,
                                height: 28,
                                position: 'absolute',
                                '&:first-of-type': {
                                    left: 0,
                                    bottom: 0,
                                    zIndex: 9
                                },
                                '&:last-of-type': {
                                    top: 0,
                                    right: 0
                                }
                            }
                        }
                    }),
                avatar: {
                    fontSize: 16,
                    fontWeight: theme.typography.fontWeightSemiBold,
                    '&:first-of-type': {
                        fontSize: 12,
                        color: theme.palette.primary.dark,
                        backgroundColor: theme.palette.primary.lighter
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/rating.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rating",
    ()=>rating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Rating$2f$ratingClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ratingClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Rating/ratingClasses.js [app-ssr] (ecmascript) <export default as ratingClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$svgIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__svgIconClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/SvgIcon/svgIconClasses.js [app-ssr] (ecmascript) <export default as svgIconClasses>");
;
;
;
function rating(theme) {
    return {
        MuiRating: {
            styleOverrides: {
                root: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Rating$2f$ratingClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ratingClasses$3e$__["ratingClasses"].disabled}`]: {
                        opacity: 0.48
                    }
                },
                iconEmpty: {
                    color: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.48)
                },
                sizeSmall: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$svgIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__svgIconClasses$3e$__["svgIconClasses"].root}`]: {
                        width: 20,
                        height: 20
                    }
                },
                sizeMedium: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$svgIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__svgIconClasses$3e$__["svgIconClasses"].root}`]: {
                        width: 24,
                        height: 24
                    }
                },
                sizeLarge: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$svgIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__svgIconClasses$3e$__["svgIconClasses"].root}`]: {
                        width: 28,
                        height: 28
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/slider.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "slider",
    ()=>slider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$sliderClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__sliderClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Slider/sliderClasses.js [app-ssr] (ecmascript) <export default as sliderClasses>");
;
function slider(theme) {
    const lightMode = theme.palette.mode === 'light';
    return {
        MuiSlider: {
            styleOverrides: {
                root: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Slider$2f$sliderClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__sliderClasses$3e$__["sliderClasses"].disabled}`]: {
                        color: theme.palette.action.disabled
                    }
                },
                rail: {
                    opacity: 0.32
                },
                markLabel: {
                    fontSize: 13,
                    color: theme.palette.text.disabled
                },
                valueLabel: {
                    borderRadius: 8,
                    backgroundColor: theme.palette.grey[lightMode ? 800 : 700]
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "button",
    ()=>button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$buttonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/buttonClasses.js [app-ssr] (ecmascript) <export default as buttonClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function button(theme) {
    const lightMode = theme.palette.mode === 'light';
    const rootStyles = (ownerState)=>{
        const inheritColor = ownerState.color === 'inherit';
        const containedVariant = ownerState.variant === 'contained';
        const outlinedVariant = ownerState.variant === 'outlined';
        const textVariant = ownerState.variant === 'text';
        const softVariant = ownerState.variant === 'soft';
        const smallSize = ownerState.size === 'small';
        const mediumSize = ownerState.size === 'medium';
        const largeSize = ownerState.size === 'large';
        const defaultStyle = {
            ...inheritColor && {
                // CONTAINED
                ...containedVariant && {
                    color: lightMode ? theme.palette.common.white : theme.palette.grey[800],
                    backgroundColor: lightMode ? theme.palette.grey[800] : theme.palette.common.white,
                    '&:hover': {
                        backgroundColor: lightMode ? theme.palette.grey[700] : theme.palette.grey[400]
                    }
                },
                // OUTLINED
                ...outlinedVariant && {
                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.32),
                    '&:hover': {
                        backgroundColor: theme.palette.action.hover
                    }
                },
                // TEXT
                ...textVariant && {
                    '&:hover': {
                        backgroundColor: theme.palette.action.hover
                    }
                },
                // SOFT
                ...softVariant && {
                    color: theme.palette.text.primary,
                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.08),
                    '&:hover': {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.24)
                    }
                }
            },
            ...outlinedVariant && {
                '&:hover': {
                    borderColor: 'currentColor',
                    boxShadow: '0 0 0 0.5px currentColor'
                }
            }
        };
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.color === color && {
                    // CONTAINED
                    ...containedVariant && {
                        '&:hover': {
                            boxShadow: theme.customShadows[color]
                        }
                    },
                    // SOFT
                    ...softVariant && {
                        color: theme.palette[color][lightMode ? 'dark' : 'light'],
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.16),
                        '&:hover': {
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.32)
                        }
                    }
                }
            }));
        const disabledState = {
            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$buttonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonClasses$3e$__["buttonClasses"].disabled}`]: {
                // SOFT
                ...softVariant && {
                    backgroundColor: theme.palette.action.disabledBackground
                }
            }
        };
        const size = {
            ...smallSize && {
                height: 30,
                fontSize: 13,
                paddingLeft: 8,
                paddingRight: 8,
                ...textVariant && {
                    paddingLeft: 4,
                    paddingRight: 4
                }
            },
            ...mediumSize && {
                paddingLeft: 12,
                paddingRight: 12,
                ...textVariant && {
                    paddingLeft: 8,
                    paddingRight: 8
                }
            },
            ...largeSize && {
                height: 48,
                fontSize: 15,
                paddingLeft: 16,
                paddingRight: 16,
                ...textVariant && {
                    paddingLeft: 10,
                    paddingRight: 10
                }
            }
        };
        return [
            defaultStyle,
            ...colorStyle,
            disabledState,
            size
        ];
    };
    return {
        MuiButton: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/select.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "select",
    ()=>select
]);
function select(theme) {
    return {
        MuiSelect: {
            styleOverrides: {
                icon: {
                    right: 10,
                    width: 18,
                    height: 18,
                    top: 'calc(50% - 9px)'
                }
            }
        },
        MuiNativeSelect: {
            styleOverrides: {
                icon: {
                    right: 10,
                    width: 18,
                    height: 18,
                    top: 'calc(50% - 9px)'
                }
            }
        }
    };
}
}),
"[project]/src/components/iconify/types.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/src/components/iconify/iconify.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$iconify$2f$react$2f$dist$2f$iconify$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@iconify/react/dist/iconify.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-ssr] (ecmascript)");
;
;
;
;
const Iconify = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ icon, width = 20, sx, ...other }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ref: ref,
        component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$iconify$2f$react$2f$dist$2f$iconify$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Icon"],
        className: "component-iconify",
        icon: icon,
        sx: {
            width,
            height: width,
            ...sx
        },
        ...other
    }, void 0, false, {
        fileName: "[project]/src/components/iconify/iconify.tsx",
        lineNumber: 15,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
Iconify.displayName = "Iconify";
const __TURBOPACK__default__export__ = Iconify;
}),
"[project]/src/components/iconify/index.ts [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/iconify/types.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/iconify/iconify.tsx [app-ssr] (ecmascript)");
;
;
}),
"[project]/src/theme/overrides/default-props.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultProps",
    ()=>defaultProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/SvgIcon/SvgIcon.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/iconify/index.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/iconify/iconify.tsx [app-ssr] (ecmascript)");
;
;
;
// ----------------------------------------------------------------------
const ArrowDownIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M12,16 C11.7663478,16.0004565 11.5399121,15.9190812 11.36,15.77 L5.36,10.77 C4.93474074,10.4165378 4.87653776,9.78525926 5.23,9.36 C5.58346224,8.93474074 6.21474074,8.87653776 6.64,9.23 L12,13.71 L17.36,9.39 C17.5665934,9.2222295 17.8315409,9.14373108 18.0961825,9.17188444 C18.3608241,9.2000378 18.6033268,9.33252029 18.77,9.54 C18.9551341,9.74785947 19.0452548,10.0234772 19.0186853,10.3005589 C18.9921158,10.5776405 18.8512608,10.8311099 18.63,11 L12.63,15.83 C12.444916,15.955516 12.2231011,16.0153708 12,16 Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 10,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const CheckboxIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M17.9 2.318A5 5 0 0 1 22.895 7.1l.005.217v10a5 5 0 0 1-4.783 4.995l-.217.005h-10a5 5 0 0 1-4.995-4.783l-.005-.217v-10a5 5 0 0 1 4.783-4.996l.217-.004h10Zm-.5 1.5h-9a4 4 0 0 0-4 4v9a4 4 0 0 0 4 4h9a4 4 0 0 0 4-4v-9a4 4 0 0 0-4-4Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 16,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 15,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const CheckboxCheckedIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M17 2a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm-1.625 7.255-4.13 4.13-1.75-1.75a.881.881 0 0 0-1.24 0c-.34.34-.34.89 0 1.24l2.38 2.37c.17.17.39.25.61.25.23 0 .45-.08.62-.25l4.75-4.75c.34-.34.34-.89 0-1.24a.881.881 0 0 0-1.24 0Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 22,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 21,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const CheckboxIndeterminateIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M17,2 C19.7614,2 22,4.23858 22,7 L22,7 L22,17 C22,19.7614 19.7614,22 17,22 L17,22 L7,22 C4.23858,22 2,19.7614 2,17 L2,17 L2,7 C2,4.23858 4.23858,2 7,2 L7,2 Z M15,11 L9,11 C8.44772,11 8,11.4477 8,12 C8,12.5523 8.44772,13 9,13 L15,13 C15.5523,13 16,12.5523 16,12 C16,11.4477 15.5523,11 15,11 Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 28,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 27,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const RadioIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M12 2A10 10 0 1 1 2 12C2 6.477 6.477 2 12 2Zm0 1.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 34,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 33,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const RadioCheckedIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M12 2A10 10 0 1 1 2 12C2 6.477 6.477 2 12 2Zm0 1.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17ZM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 40,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const RatingIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M17.56,21 C17.4000767,21.0006435 17.2423316,20.9629218 17.1,20.89 L12,18.22 L6.9,20.89 C6.56213339,21.067663 6.15259539,21.0374771 5.8444287,20.8121966 C5.53626201,20.5869161 5.38323252,20.2058459 5.45,19.83 L6.45,14.2 L2.33,10.2 C2.06805623,9.93860108 1.9718844,9.55391377 2.08,9.2 C2.19824414,8.83742187 2.51242293,8.57366684 2.89,8.52 L8.59,7.69 L11.1,2.56 C11.2670864,2.21500967 11.6166774,1.99588989 12,1.99588989 C12.3833226,1.99588989 12.7329136,2.21500967 12.9,2.56 L15.44,7.68 L21.14,8.51 C21.5175771,8.56366684 21.8317559,8.82742187 21.95,9.19 C22.0581156,9.54391377 21.9619438,9.92860108 21.7,10.19 L17.58,14.19 L18.58,19.82 C18.652893,20.2027971 18.4967826,20.5930731 18.18,20.82 C17.9989179,20.9468967 17.7808835,21.010197 17.56,21 L17.56,21 Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 46,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 45,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const TreeViewCollapseIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M18,3 C19.6568542,3 21,4.34314575 21,6 L21,6 L21,18 C21,19.6568542 19.6568542,21 18,21 L18,21 L6,21 C4.34314575,21 3,19.6568542 3,18 L3,18 L3,6 C3,4.34314575 4.34314575,3 6,3 L6,3 Z M18,5 L6,5 C5.44771525,5 5,5.44771525 5,6 L5,6 L5,18 C5,18.5522847 5.44771525,19 6,19 L6,19 L18,19 C18.5522847,19 19,18.5522847 19,18 L19,18 L19,6 C19,5.44771525 18.5522847,5 18,5 L18,5 Z M12,8 C12.5522847,8 13,8.44771525 13,9 L13,9 L13,11 L15,11 C15.5522847,11 16,11.4477153 16,12 C16,12.5522847 15.5522847,13 15,13 L15,13 L13,13 L13,15 C13,15.5522847 12.5522847,16 12,16 C11.4477153,16 11,15.5522847 11,15 L11,15 L11,13 L9,13 C8.44771525,13 8,12.5522847 8,12 C8,11.4477153 8.44771525,11 9,11 L9,11 L11,11 L11,9 C11,8.44771525 11.4477153,8 12,8 Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 52,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 51,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const TreeViewExpandIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M18,3 C19.6568542,3 21,4.34314575 21,6 L21,6 L21,18 C21,19.6568542 19.6568542,21 18,21 L18,21 L6,21 C4.34314575,21 3,19.6568542 3,18 L3,18 L3,6 C3,4.34314575 4.34314575,3 6,3 L6,3 Z M18,5 L6,5 C5.44771525,5 5,5.44771525 5,6 L5,6 L5,18 C5,18.5522847 5.44771525,19 6,19 L6,19 L18,19 C18.5522847,19 19,18.5522847 19,18 L19,18 L19,6 C19,5.44771525 18.5522847,5 18,5 L18,5 Z M15,11 C15.5522847,11 16,11.4477153 16,12 C16,12.5522847 15.5522847,13 15,13 L15,13 L9,13 C8.44771525,13 8,12.5522847 8,12 C8,11.4477153 8.44771525,11 9,11 L9,11 Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 58,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 57,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const TreeViewEndIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M18,3 C19.6568542,3 21,4.34314575 21,6 L21,6 L21,18 C21,19.6568542 19.6568542,21 18,21 L18,21 L6,21 C4.34314575,21 3,19.6568542 3,18 L3,18 L3,6 C3,4.34314575 4.34314575,3 6,3 L6,3 Z M18,5 L6,5 C5.44771525,5 5,5.44771525 5,6 L5,6 L5,18 C5,18.5522847 5.44771525,19 6,19 L6,19 L18,19 C18.5522847,19 19,18.5522847 19,18 L19,18 L19,6 C19,5.44771525 18.5522847,5 18,5 L18,5 Z M14,8.99420168 C14.2666375,8.99420168 14.5222334,9.10068735 14.71,9.29 C14.8993127,9.4777666 15.0057983,9.73336246 15.0057983,10 C15.0057983,10.2666375 14.8993127,10.5222334 14.71,10.71 L14.71,10.71 L13.41,12 L14.71,13.29 C14.8993127,13.4777666 15.0057983,13.7333625 15.0057983,14 C15.0057983,14.2666375 14.8993127,14.5222334 14.71,14.71 C14.5222334,14.8993127 14.2666375,15.0057983 14,15.0057983 C13.7333625,15.0057983 13.4777666,14.8993127 13.29,14.71 L13.29,14.71 L12,13.41 L10.71,14.71 C10.5222334,14.8993127 10.2666375,15.0057983 10,15.0057983 C9.73336246,15.0057983 9.4777666,14.8993127 9.29,14.71 C9.10068735,14.5222334 8.99420168,14.2666375 8.99420168,14 C8.99420168,13.7333625 9.10068735,13.4777666 9.29,13.29 L9.29,13.29 L10.59,12 L9.29,10.71 C8.89787783,10.3178778 8.89787783,9.68212217 9.29,9.29 C9.68212217,8.89787783 10.3178778,8.89787783 10.71,9.29 L10.71,9.29 L12,10.59 L13.29,9.29 C13.4777666,9.10068735 13.7333625,8.99420168 14,8.99420168 Z"
        }, void 0, false, {
            fileName: "[project]/src/theme/overrides/default-props.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/default-props.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
function defaultProps(theme) {
    return {
        MuiAlert: {
            defaultProps: {
                iconMapping: {
                    error: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        icon: "solar:danger-bold",
                        width: 24
                    }, void 0, false, {
                        fileName: "[project]/src/theme/overrides/default-props.tsx",
                        lineNumber: 75,
                        columnNumber: 18
                    }, this),
                    info: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        icon: "eva:info-fill",
                        width: 24
                    }, void 0, false, {
                        fileName: "[project]/src/theme/overrides/default-props.tsx",
                        lineNumber: 76,
                        columnNumber: 17
                    }, this),
                    success: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        icon: "eva:checkmark-circle-2-fill",
                        width: 24
                    }, void 0, false, {
                        fileName: "[project]/src/theme/overrides/default-props.tsx",
                        lineNumber: 77,
                        columnNumber: 20
                    }, this),
                    warning: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        icon: "eva:alert-triangle-fill",
                        width: 24
                    }, void 0, false, {
                        fileName: "[project]/src/theme/overrides/default-props.tsx",
                        lineNumber: 78,
                        columnNumber: 20
                    }, this)
                }
            }
        },
        MuiStack: {
            defaultProps: {
                useFlexGap: true
            }
        },
        MuiAppBar: {
            defaultProps: {
                color: "transparent"
            }
        },
        MuiAvatarGroup: {
            defaultProps: {
                max: 4
            }
        },
        MuiButtonGroup: {
            defaultProps: {
                disableElevation: true
            }
        },
        MuiButton: {
            defaultProps: {
                color: "inherit",
                disableElevation: true
            }
        },
        MuiCardHeader: {
            defaultProps: {
                titleTypographyProps: {
                    variant: "h6"
                },
                subheaderTypographyProps: {
                    variant: "body2",
                    marginTop: theme.spacing(0.5)
                }
            }
        },
        MuiChip: {
            defaultProps: {
                deleteIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    icon: "solar:close-circle-bold"
                }, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 119,
                    columnNumber: 21
                }, this)
            }
        },
        MuiDialogActions: {
            defaultProps: {
                disableSpacing: true
            }
        },
        MuiFab: {
            defaultProps: {
                color: "primary"
            }
        },
        MuiLink: {
            defaultProps: {
                underline: "hover"
            }
        },
        MuiListItemText: {
            defaultProps: {
                primaryTypographyProps: {
                    typography: "subtitle2"
                },
                secondaryTypographyProps: {
                    component: "span"
                }
            }
        },
        MuiPaper: {
            defaultProps: {
                elevation: 0
            }
        },
        MuiSkeleton: {
            defaultProps: {
                animation: "wave",
                variant: "rounded"
            }
        },
        MuiFilledInput: {
            defaultProps: {
                disableUnderline: true
            }
        },
        MuiFormHelperText: {
            defaultProps: {
                component: "div"
            }
        },
        MuiTab: {
            defaultProps: {
                disableRipple: true,
                iconPosition: "start"
            }
        },
        MuiTabs: {
            defaultProps: {
                textColor: "inherit",
                variant: "scrollable",
                allowScrollButtonsMobile: true
            }
        },
        MuiTablePagination: {
            defaultProps: {
                backIconButtonProps: {
                    size: "small"
                },
                nextIconButtonProps: {
                    size: "small"
                }
            }
        },
        MuiSlider: {
            defaultProps: {
                size: "small"
            }
        },
        MuiAutocomplete: {
            defaultProps: {
                popupIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ArrowDownIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 198,
                    columnNumber: 20
                }, this)
            }
        },
        MuiSelect: {
            defaultProps: {
                IconComponent: ArrowDownIcon
            }
        },
        MuiNativeSelect: {
            defaultProps: {
                IconComponent: ArrowDownIcon
            }
        },
        MuiCheckbox: {
            defaultProps: {
                size: "small",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CheckboxIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 214,
                    columnNumber: 15
                }, this),
                checkedIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CheckboxCheckedIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 215,
                    columnNumber: 22
                }, this),
                indeterminateIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CheckboxIndeterminateIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 216,
                    columnNumber: 28
                }, this)
            }
        },
        MuiRadio: {
            defaultProps: {
                size: "small",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RadioIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 222,
                    columnNumber: 15
                }, this),
                checkedIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RadioCheckedIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 223,
                    columnNumber: 22
                }, this)
            }
        },
        MuiRating: {
            defaultProps: {
                emptyIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RatingIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 228,
                    columnNumber: 20
                }, this),
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RatingIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 229,
                    columnNumber: 15
                }, this)
            }
        },
        MuiTreeView: {
            defaultProps: {
                defaultCollapseIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TreeViewCollapseIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 234,
                    columnNumber: 30
                }, this),
                defaultExpandIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TreeViewExpandIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 235,
                    columnNumber: 28
                }, this),
                defaultEndIcon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TreeViewEndIcon, {}, void 0, false, {
                    fileName: "[project]/src/theme/overrides/default-props.tsx",
                    lineNumber: 236,
                    columnNumber: 25
                }, this)
            }
        },
        MuiDataGrid: {
            defaultProps: {
                slots: {
                    // column
                    columnSortedAscendingIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:alt-arrow-up-bold-duotone",
                            sx: {
                                color: "text.primary"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 244,
                            columnNumber: 13
                        }, this),
                    columnSortedDescendingIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:alt-arrow-down-bold-duotone",
                            sx: {
                                color: "text.primary"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 251,
                            columnNumber: 13
                        }, this),
                    columnUnsortedIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:alt-arrow-up-bold-duotone",
                            sx: {
                                color: "text.disabled"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 258,
                            columnNumber: 13
                        }, this),
                    columnMenuIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "mingcute:more-1-fill"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 265,
                            columnNumber: 13
                        }, this),
                    columnMenuSortAscendingIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:alt-arrow-up-bold-duotone"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 268,
                            columnNumber: 13
                        }, this),
                    columnMenuSortDescendingIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:alt-arrow-down-bold-duotone"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 271,
                            columnNumber: 13
                        }, this),
                    columnMenuFilterIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:filter-bold"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 274,
                            columnNumber: 13
                        }, this),
                    columnMenuHideIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:eye-closed-bold"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 277,
                            columnNumber: 13
                        }, this),
                    columnMenuManageColumnsIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:eye-bold"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 280,
                            columnNumber: 13
                        }, this),
                    columnSelectorIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:eye-bold"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 283,
                            columnNumber: 13
                        }, this),
                    // filter
                    filterPanelDeleteIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "eva:close-fill"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 287,
                            columnNumber: 13
                        }, this),
                    openFilterButtonIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:filter-bold"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 290,
                            columnNumber: 13
                        }, this),
                    columnFilteredIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 16,
                            icon: "solar:filter-bold",
                            sx: {
                                color: "text.primary"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 293,
                            columnNumber: 13
                        }, this),
                    // density
                    densityCompactIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "material-symbols:table-rows-narrow-rounded"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 301,
                            columnNumber: 13
                        }, this),
                    densityStandardIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "mingcute:rows-4-fill"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 307,
                            columnNumber: 13
                        }, this),
                    densityComfortableIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "mingcute:rows-2-fill"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 310,
                            columnNumber: 13
                        }, this),
                    // export
                    exportIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "solar:export-bold"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 313,
                            columnNumber: 29
                        }, this),
                    // quick filter
                    quickFilterIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 24,
                            icon: "eva:search-fill",
                            sx: {
                                color: "text.secondary"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 316,
                            columnNumber: 13
                        }, this),
                    quickFilterClearIcon: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            width: 20,
                            icon: "eva:close-fill"
                        }, void 0, false, {
                            fileName: "[project]/src/theme/overrides/default-props.tsx",
                            lineNumber: 323,
                            columnNumber: 13
                        }, this)
                },
                slotProps: {
                    basePopper: {
                        placement: "bottom-end"
                    },
                    baseTextField: {
                        variant: "outlined",
                        InputLabelProps: {
                            shrink: true
                        }
                    },
                    baseFormControl: {
                        variant: "outlined"
                    },
                    baseSelect: {
                        variant: "outlined"
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/switch.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "switches",
    ()=>switches
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/switchClasses.js [app-ssr] (ecmascript) <export default as switchClasses>");
;
;
function switches(theme) {
    const lightMode = theme.palette.mode === 'light';
    const rootStyles = (ownerState)=>{
        const { color } = ownerState;
        return {
            width: 58,
            height: 38,
            padding: '9px 13px 9px 12px',
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].thumb}`]: {
                width: 14,
                height: 14,
                boxShadow: 'none',
                color: theme.palette.common.white
            },
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].track}`]: {
                opacity: 1,
                borderRadius: 14,
                backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.48)
            },
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].switchBase}`]: {
                left: 3,
                padding: 12,
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].checked}`]: {
                    transform: 'translateX(13px)',
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].thumb}`]: {
                        ...color === 'default' && !lightMode && {
                            color: theme.palette.grey[800]
                        }
                    },
                    [`&+.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].track}`]: {
                        opacity: 1,
                        ...color === 'default' && {
                            backgroundColor: theme.palette.text.primary
                        }
                    }
                },
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].disabled}`]: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].thumb}`]: {
                        opacity: lightMode ? 1 : 0.48
                    },
                    [`&+.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].track}`]: {
                        opacity: 0.48
                    }
                }
            },
            // Small
            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].sizeSmall}`]: {
                padding: '4px 8px 4px 7px',
                width: 40,
                height: 24,
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].thumb}`]: {
                    width: 10,
                    height: 10
                },
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].switchBase}`]: {
                    padding: 7,
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$switchClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__switchClasses$3e$__["switchClasses"].checked}`]: {
                        transform: 'translateX(9px)'
                    }
                }
            }
        };
    };
    return {
        MuiSwitch: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/tooltip.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tooltip",
    ()=>tooltip
]);
function tooltip(theme) {
    const lightMode = theme.palette.mode === 'light';
    return {
        MuiTooltip: {
            styleOverrides: {
                tooltip: {
                    backgroundColor: theme.palette.grey[lightMode ? 800 : 700]
                },
                arrow: {
                    color: theme.palette.grey[lightMode ? 800 : 700]
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/popover.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "popover",
    ()=>popover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$listClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__listClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/listClasses.js [app-ssr] (ecmascript) <export default as listClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/css.ts [app-ssr] (ecmascript)");
;
;
function popover(theme) {
    return {
        MuiPopover: {
            styleOverrides: {
                paper: {
                    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paper"])({
                        theme,
                        dropdown: true
                    }),
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$listClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__listClasses$3e$__["listClasses"].root}`]: {
                        paddingTop: 0,
                        paddingBottom: 0
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/stepper.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stepper",
    ()=>stepper
]);
function stepper(theme) {
    return {
        MuiStepConnector: {
            styleOverrides: {
                line: {
                    borderColor: theme.palette.divider
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/svg-icon.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "svgIcon",
    ()=>svgIcon
]);
function svgIcon(theme) {
    return {
        MuiSvgIcon: {
            styleOverrides: {
                fontSizeLarge: {
                    width: 32,
                    height: 32,
                    fontSize: 'inherit'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/skeleton.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "skeleton",
    ()=>skeleton
]);
function skeleton(theme) {
    return {
        MuiSkeleton: {
            styleOverrides: {
                root: {
                    backgroundColor: theme.palette.background.neutral
                },
                rounded: {
                    borderRadius: theme.shape.borderRadius * 2
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/backdrop.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "backdrop",
    ()=>backdrop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
;
function backdrop(theme) {
    return {
        MuiBackdrop: {
            styleOverrides: {
                root: {
                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[900], 0.8)
                },
                invisible: {
                    background: 'transparent'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/progress.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "progress",
    ()=>progress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$linearProgressClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__linearProgressClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/linearProgressClasses.js [app-ssr] (ecmascript) <export default as linearProgressClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function progress(theme) {
    const rootStyles = (ownerState)=>{
        const bufferVariant = ownerState.variant === 'buffer';
        const defaultStyle = {
            borderRadius: 4,
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$linearProgressClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__linearProgressClasses$3e$__["linearProgressClasses"].bar}`]: {
                borderRadius: 4
            },
            ...bufferVariant && {
                backgroundColor: 'transparent'
            }
        };
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.color === color && {
                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.24)
                }
            }));
        return [
            defaultStyle,
            ...colorStyle
        ];
    };
    return {
        MuiLinearProgress: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/timeline.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "timeline",
    ()=>timeline
]);
function timeline(theme) {
    return {
        MuiTimelineDot: {
            styleOverrides: {
                root: {
                    boxShadow: 'none'
                }
            }
        },
        MuiTimelineConnector: {
            styleOverrides: {
                root: {
                    backgroundColor: theme.palette.divider
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/checkbox.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkbox",
    ()=>checkbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$checkboxClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__checkboxClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/checkboxClasses.js [app-ssr] (ecmascript) <export default as checkboxClasses>");
;
function checkbox(theme) {
    return {
        MuiCheckbox: {
            styleOverrides: {
                root: ({ ownerState })=>{
                    const { color } = ownerState;
                    return {
                        padding: theme.spacing(1),
                        ...color === 'default' && {
                            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$checkboxClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__checkboxClasses$3e$__["checkboxClasses"].checked}`]: {
                                color: theme.palette.text.primary
                            }
                        },
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$checkboxClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__checkboxClasses$3e$__["checkboxClasses"].disabled}`]: {
                            color: theme.palette.action.disabled
                        }
                    };
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/data-grid.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dataGrid",
    ()=>dataGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$listClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__listClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/listClasses.js [app-ssr] (ecmascript) <export default as listClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$paperClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paperClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/paperClasses.js [app-ssr] (ecmascript) <export default as paperClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$buttonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/buttonClasses.js [app-ssr] (ecmascript) <export default as buttonClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__iconButtonClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/iconButtonClasses.js [app-ssr] (ecmascript) <export default as iconButtonClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/inputLabelClasses.js [app-ssr] (ecmascript) <export default as inputLabelClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__formControlClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/formControlClasses.js [app-ssr] (ecmascript) <export default as formControlClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$listItemIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__listItemIconClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/listItemIconClasses.js [app-ssr] (ecmascript) <export default as listItemIconClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$circularProgressClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__circularProgressClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CircularProgress/circularProgressClasses.js [app-ssr] (ecmascript) <export default as circularProgressClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/css.ts [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function dataGrid(theme) {
    const paperStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paper"])({
        theme,
        dropdown: true
    });
    return {
        MuiDataGrid: {
            styleOverrides: {
                root: {
                    '--unstable_DataGrid-radius': 0,
                    '--unstable_DataGrid-headWeight': theme.typography.fontWeightSemiBold,
                    borderWidth: 0
                },
                withBorderColor: {
                    borderColor: theme.palette.divider
                },
                // Column
                columnHeaders: {
                    borderBottom: 0
                },
                columnHeader: {
                    fontSize: 14,
                    color: theme.palette.text.secondary,
                    backgroundColor: theme.palette.background.neutral,
                    '&--sorted': {
                        color: theme.palette.text.primary
                    }
                },
                columnSeparator: {
                    color: theme.palette.divider
                },
                // Row, Cell
                cell: {
                    borderBottom: `1px dashed`,
                    '&--editing': {
                        boxShadow: 'none !important',
                        backgroundColor: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.primary.main, 0.08)} !important`
                    }
                },
                // Toolbar
                toolbarContainer: {
                    gap: theme.spacing(2),
                    padding: theme.spacing(2)
                },
                toolbarQuickFilter: {
                    padding: 0,
                    width: '100%',
                    [theme.breakpoints.up('md')]: {
                        width: 'unset'
                    }
                },
                // Paper
                paper: {
                    ...paperStyles,
                    padding: 0
                },
                menu: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$paperClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paperClasses$3e$__["paperClasses"].root}`]: {
                        ...paperStyles,
                        minWidth: 140
                    },
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$listClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__listClasses$3e$__["listClasses"].root}`]: {
                        padding: 0,
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$listItemIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__listItemIconClasses$3e$__["listItemIconClasses"].root}`]: {
                            minWidth: 0,
                            marginRight: theme.spacing(2)
                        }
                    }
                },
                // Icons
                menuIcon: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__iconButtonClasses$3e$__["iconButtonClasses"].root}`]: {
                        margin: theme.spacing(0, 1),
                        padding: theme.spacing(0.25)
                    }
                },
                iconButtonContainer: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__iconButtonClasses$3e$__["iconButtonClasses"].root}`]: {
                        padding: theme.spacing(0.25),
                        marginLeft: theme.spacing(1)
                    }
                },
                // Footer
                footerContainer: {
                    minHeight: 'auto',
                    borderTop: `1px dashed`
                },
                selectedRowCount: {
                    display: 'none',
                    whiteSpace: 'nowrap'
                },
                overlay: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$circularProgressClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__circularProgressClasses$3e$__["circularProgressClasses"].root}`]: {
                        color: theme.palette.text.primary
                    }
                },
                // Columns Panel
                panelHeader: {
                    padding: theme.spacing(2, 2, 0, 2)
                },
                panelContent: {
                    padding: theme.spacing(1)
                },
                columnsPanelRow: {
                    margin: theme.spacing(0.5, 0)
                },
                panelFooter: {
                    display: 'none',
                    gap: theme.spacing(1),
                    padding: theme.spacing(2),
                    justifyContent: 'flex-end',
                    borderTop: `dashed 1px ${theme.palette.divider}`,
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$buttonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonClasses$3e$__["buttonClasses"].root}`]: {
                        padding: theme.spacing(0.5, 1.5),
                        '&:first-of-type': {
                            border: `solid 1px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.24)}`
                        },
                        '&:last-of-type': {
                            color: theme.palette.background.paper,
                            backgroundColor: theme.palette.text.primary
                        }
                    }
                },
                filterForm: {
                    alignItems: 'center',
                    gap: theme.spacing(1.5),
                    padding: theme.spacing(1)
                },
                filterFormValueInput: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$formControlClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__formControlClasses$3e$__["formControlClasses"].root}`]: {
                        width: '100%'
                    },
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__["inputLabelClasses"].root}`]: {
                        transform: 'translate(14px, -9px) scale(0.75)'
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/tree-view.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "treeView",
    ()=>treeView
]);
function treeView(theme) {
    return {
        MuiTreeItem: {
            styleOverrides: {
                label: {
                    ...theme.typography.body2
                },
                iconContainer: {
                    width: 'auto'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/textfield.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "textField",
    ()=>textField
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputBase/inputBaseClasses.js [app-ssr] (ecmascript) <export default as inputBaseClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/inputLabelClasses.js [app-ssr] (ecmascript) <export default as inputLabelClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__filledInputClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FilledInput/filledInputClasses.js [app-ssr] (ecmascript) <export default as filledInputClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/OutlinedInput/outlinedInputClasses.js [app-ssr] (ecmascript) <export default as outlinedInputClasses>");
;
;
;
;
;
function textField(theme) {
    const color = {
        focused: theme.palette.text.primary,
        active: theme.palette.text.secondary,
        placeholder: theme.palette.text.disabled
    };
    const font = {
        label: theme.typography.body1,
        value: theme.typography.body2
    };
    return {
        // HELPER
        MuiFormHelperText: {
            styleOverrides: {
                root: {
                    marginTop: theme.spacing(1)
                }
            }
        },
        // LABEL
        MuiFormLabel: {
            styleOverrides: {
                root: {
                    ...font.value,
                    color: color.placeholder,
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__["inputLabelClasses"].shrink}`]: {
                        ...font.label,
                        fontWeight: 600,
                        color: color.active,
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__["inputLabelClasses"].focused}`]: {
                            color: color.focused
                        },
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__["inputLabelClasses"].error}`]: {
                            color: theme.palette.error.main
                        },
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__["inputLabelClasses"].disabled}`]: {
                            color: theme.palette.text.disabled
                        },
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$inputLabelClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputLabelClasses$3e$__["inputLabelClasses"].filled}`]: {
                            transform: 'translate(12px, 6px) scale(0.75)'
                        }
                    }
                }
            }
        },
        // BASE
        MuiInputBase: {
            styleOverrides: {
                root: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$inputBaseClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__inputBaseClasses$3e$__["inputBaseClasses"].disabled}`]: {
                        '& svg': {
                            color: theme.palette.text.disabled
                        }
                    }
                },
                input: {
                    ...font.value,
                    '&::placeholder': {
                        opacity: 1,
                        color: color.placeholder
                    }
                }
            }
        },
        // STANDARD
        MuiInput: {
            styleOverrides: {
                underline: {
                    '&:before': {
                        borderBottomColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.32)
                    },
                    '&:after': {
                        borderBottomColor: color.focused
                    }
                }
            }
        },
        // OUTLINED
        MuiOutlinedInput: {
            styleOverrides: {
                root: {
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__["outlinedInputClasses"].focused}`]: {
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__["outlinedInputClasses"].notchedOutline}`]: {
                            borderColor: color.focused
                        }
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__["outlinedInputClasses"].error}`]: {
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__["outlinedInputClasses"].notchedOutline}`]: {
                            borderColor: theme.palette.error.main
                        }
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__["outlinedInputClasses"].disabled}`]: {
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$OutlinedInput$2f$outlinedInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__outlinedInputClasses$3e$__["outlinedInputClasses"].notchedOutline}`]: {
                            borderColor: theme.palette.action.disabledBackground
                        }
                    }
                },
                notchedOutline: {
                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.2),
                    transition: theme.transitions.create([
                        'border-color'
                    ], {
                        duration: theme.transitions.duration.shortest
                    })
                }
            }
        },
        // FILLED
        MuiFilledInput: {
            styleOverrides: {
                root: {
                    borderRadius: theme.shape.borderRadius,
                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.08),
                    '&:hover': {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.16)
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__filledInputClasses$3e$__["filledInputClasses"].focused}`]: {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.16)
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__filledInputClasses$3e$__["filledInputClasses"].error}`]: {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.error.main, 0.08),
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__filledInputClasses$3e$__["filledInputClasses"].focused}`]: {
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.error.main, 0.16)
                        }
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FilledInput$2f$filledInputClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__filledInputClasses$3e$__["filledInputClasses"].disabled}`]: {
                        backgroundColor: theme.palette.action.disabledBackground
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/accordion.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "accordion",
    ()=>accordion
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$accordionClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__accordionClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Accordion/accordionClasses.js [app-ssr] (ecmascript) <export default as accordionClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$typographyClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__typographyClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/typographyClasses.js [app-ssr] (ecmascript) <export default as typographyClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$accordionSummaryClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__accordionSummaryClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/AccordionSummary/accordionSummaryClasses.js [app-ssr] (ecmascript) <export default as accordionSummaryClasses>");
;
;
;
function accordion(theme) {
    return {
        MuiAccordion: {
            styleOverrides: {
                root: {
                    backgroundColor: 'transparent',
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$accordionClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__accordionClasses$3e$__["accordionClasses"].expanded}`]: {
                        boxShadow: theme.customShadows.z8,
                        borderRadius: theme.shape.borderRadius,
                        backgroundColor: theme.palette.background.paper
                    },
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Accordion$2f$accordionClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__accordionClasses$3e$__["accordionClasses"].disabled}`]: {
                        backgroundColor: 'transparent'
                    }
                }
            }
        },
        MuiAccordionSummary: {
            styleOverrides: {
                root: {
                    paddingLeft: theme.spacing(2),
                    paddingRight: theme.spacing(1),
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$AccordionSummary$2f$accordionSummaryClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__accordionSummaryClasses$3e$__["accordionSummaryClasses"].disabled}`]: {
                        opacity: 1,
                        color: theme.palette.action.disabled,
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$typographyClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__typographyClasses$3e$__["typographyClasses"].root}`]: {
                            color: 'inherit'
                        }
                    }
                },
                expandIconWrapper: {
                    color: 'inherit'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/typography.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "typography",
    ()=>typography
]);
function typography(theme) {
    return {
        MuiTypography: {
            styleOverrides: {
                paragraph: {
                    marginBottom: theme.spacing(2)
                },
                gutterBottom: {
                    marginBottom: theme.spacing(1)
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/pagination.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pagination",
    ()=>pagination
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$PaginationItem$2f$paginationItemClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paginationItemClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/PaginationItem/paginationItemClasses.js [app-ssr] (ecmascript) <export default as paginationItemClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function pagination(theme) {
    const lightMode = theme.palette.mode === 'light';
    const rootStyles = (ownerState)=>{
        const defaultColor = ownerState.color === 'standard';
        const filledVariant = ownerState.variant === 'text';
        const outlinedVariant = ownerState.variant === 'outlined';
        const softVariant = ownerState.variant === 'soft';
        const defaultStyle = {
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$PaginationItem$2f$paginationItemClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paginationItemClasses$3e$__["paginationItemClasses"].root}`]: {
                ...outlinedVariant && {
                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.24)
                },
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$PaginationItem$2f$paginationItemClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paginationItemClasses$3e$__["paginationItemClasses"].selected}`]: {
                    fontWeight: theme.typography.fontWeightSemiBold,
                    ...outlinedVariant && {
                        borderColor: 'currentColor'
                    },
                    ...defaultColor && {
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.08),
                        ...filledVariant && {
                            color: lightMode ? theme.palette.common.white : theme.palette.grey[800],
                            backgroundColor: theme.palette.text.primary,
                            '&:hover': {
                                backgroundColor: lightMode ? theme.palette.grey[700] : theme.palette.grey[100]
                            }
                        }
                    }
                }
            }
        };
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.color === color && {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$PaginationItem$2f$paginationItemClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paginationItemClasses$3e$__["paginationItemClasses"].root}`]: {
                        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$PaginationItem$2f$paginationItemClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__paginationItemClasses$3e$__["paginationItemClasses"].selected}`]: {
                            ...ownerState.color === color && {
                                // SOFT
                                ...softVariant && {
                                    color: theme.palette[color][lightMode ? 'dark' : 'light'],
                                    backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.08),
                                    '&:hover': {
                                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.16)
                                    }
                                }
                            }
                        }
                    }
                }
            }));
        return [
            defaultStyle,
            ...colorStyle
        ];
    };
    return {
        MuiPagination: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/date-picker.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "datePicker",
    ()=>datePicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$buttonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/buttonClasses.js [app-ssr] (ecmascript) <export default as buttonClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/iconify/index.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/iconify/iconify.tsx [app-ssr] (ecmascript)");
;
;
;
// ----------------------------------------------------------------------
const dateList = [
    'DatePicker',
    'DateTimePicker',
    'StaticDatePicker',
    'DesktopDatePicker',
    'DesktopDateTimePicker',
    //
    'MobileDatePicker',
    'MobileDateTimePicker'
];
const timeList = [
    'TimePicker',
    'MobileTimePicker',
    'StaticTimePicker',
    'DesktopTimePicker'
];
const switchIcon = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        icon: "eva:chevron-down-fill",
        width: 24
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/components/date-picker.tsx",
        lineNumber: 21,
        columnNumber: 26
    }, ("TURBOPACK compile-time value", void 0));
const leftIcon = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        icon: "eva:arrow-ios-back-fill",
        width: 24
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/components/date-picker.tsx",
        lineNumber: 23,
        columnNumber: 24
    }, ("TURBOPACK compile-time value", void 0));
const rightIcon = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        icon: "eva:arrow-ios-forward-fill",
        width: 24
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/components/date-picker.tsx",
        lineNumber: 25,
        columnNumber: 25
    }, ("TURBOPACK compile-time value", void 0));
const calendarIcon = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        icon: "solar:calendar-mark-bold-duotone",
        width: 24
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/components/date-picker.tsx",
        lineNumber: 27,
        columnNumber: 28
    }, ("TURBOPACK compile-time value", void 0));
const clockIcon = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$iconify$2f$iconify$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        icon: "solar:clock-circle-outline",
        width: 24
    }, void 0, false, {
        fileName: "[project]/src/theme/overrides/components/date-picker.tsx",
        lineNumber: 29,
        columnNumber: 25
    }, ("TURBOPACK compile-time value", void 0));
const desktopTypes = dateList.reduce((result, currentValue)=>{
    result[`Mui${currentValue}`] = {
        defaultProps: {
            slots: {
                openPickerIcon: calendarIcon,
                leftArrowIcon: leftIcon,
                rightArrowIcon: rightIcon,
                switchViewIcon: switchIcon
            }
        }
    };
    return result;
}, {});
const timeTypes = timeList.reduce((result, currentValue)=>{
    result[`Mui${currentValue}`] = {
        defaultProps: {
            slots: {
                openPickerIcon: clockIcon,
                rightArrowIcon: rightIcon,
                switchViewIcon: switchIcon
            }
        }
    };
    return result;
}, {});
function datePicker(theme) {
    return {
        MuiPickersLayout: {
            styleOverrides: {
                root: {
                    '& .MuiPickersLayout-actionBar': {
                        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$buttonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonClasses$3e$__["buttonClasses"].root}:last-of-type`]: {
                            backgroundColor: theme.palette.text.primary,
                            color: theme.palette.mode === 'light' ? theme.palette.common.white : theme.palette.grey[800]
                        }
                    }
                }
            }
        },
        // Date
        ...desktopTypes,
        // Time
        ...timeTypes
    };
}
}),
"[project]/src/theme/overrides/components/breadcrumbs.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "breadcrumbs",
    ()=>breadcrumbs
]);
function breadcrumbs(theme) {
    return {
        MuiBreadcrumbs: {
            styleOverrides: {
                separator: {
                    marginLeft: theme.spacing(2),
                    marginRight: theme.spacing(2)
                },
                li: {
                    display: 'inline-flex',
                    margin: theme.spacing(0.25, 0),
                    '& > *': {
                        ...theme.typography.body2
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/css-baseline.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cssBaseline",
    ()=>cssBaseline
]);
function cssBaseline(theme) {
    return {
        MuiCssBaseline: {
            styleOverrides: {
                '*': {
                    boxSizing: 'border-box'
                },
                html: {
                    margin: 0,
                    padding: 0,
                    width: '100%',
                    height: '100%',
                    WebkitOverflowScrolling: 'touch'
                },
                body: {
                    margin: 0,
                    padding: 0,
                    width: '100%',
                    height: '100%'
                },
                '#root, #__next': {
                    width: '100%',
                    height: '100%'
                },
                input: {
                    '&[type=number]': {
                        MozAppearance: 'textfield',
                        '&::-webkit-outer-spin-button': {
                            margin: 0,
                            WebkitAppearance: 'none'
                        },
                        '&::-webkit-inner-spin-button': {
                            margin: 0,
                            WebkitAppearance: 'none'
                        }
                    }
                },
                img: {
                    maxWidth: '100%',
                    display: 'inline-block',
                    verticalAlign: 'bottom'
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/button-group.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buttonGroup",
    ()=>buttonGroup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$buttonGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonGroupClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ButtonGroup/buttonGroupClasses.js [app-ssr] (ecmascript) <export default as buttonGroupClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function buttonGroup(theme) {
    const rootStyles = (ownerState)=>{
        const inheritColor = ownerState.color === 'inherit';
        const containedVariant = ownerState.variant === 'contained';
        const outlinedVariant = ownerState.variant === 'outlined';
        const textVariant = ownerState.variant === 'text';
        const softVariant = ownerState.variant === 'soft';
        const horizontalOrientation = ownerState.orientation === 'horizontal';
        const verticalOrientation = ownerState.orientation === 'vertical';
        const defaultStyle = {
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$buttonGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonGroupClasses$3e$__["buttonGroupClasses"].grouped}`]: {
                '&:not(:last-of-type)': {
                    ...!outlinedVariant && {
                        borderStyle: 'solid',
                        ...inheritColor && {
                            borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.32)
                        },
                        // HORIZONTAL
                        ...horizontalOrientation && {
                            borderWidth: '0px 1px 0px 0px'
                        },
                        // VERTICAL
                        ...verticalOrientation && {
                            borderWidth: '0px 0px 1px 0px'
                        }
                    }
                }
            }
        };
        const colorStyle = COLORS.map((color)=>({
                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$buttonGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonGroupClasses$3e$__["buttonGroupClasses"].grouped}`]: {
                    '&:not(:last-of-type)': {
                        ...!outlinedVariant && {
                            ...ownerState.color === color && {
                                // CONTAINED
                                ...containedVariant && {
                                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].dark, 0.48)
                                },
                                // TEXT
                                ...textVariant && {
                                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.48)
                                },
                                // SOFT
                                ...softVariant && {
                                    borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].dark, 0.24)
                                }
                            }
                        }
                    }
                }
            }));
        const disabledState = {
            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$buttonGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonGroupClasses$3e$__["buttonGroupClasses"].grouped}`]: {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ButtonGroup$2f$buttonGroupClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__buttonGroupClasses$3e$__["buttonGroupClasses"].disabled}`]: {
                    '&:not(:last-of-type)': {
                        borderColor: theme.palette.action.disabledBackground
                    }
                }
            }
        };
        return [
            defaultStyle,
            ...colorStyle,
            disabledState
        ];
    };
    return {
        MuiButtonGroup: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/autocomplete.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "autocomplete",
    ()=>autocomplete
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$svgIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__svgIconClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/SvgIcon/svgIconClasses.js [app-ssr] (ecmascript) <export default as svgIconClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$autocompleteClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__autocompleteClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/autocompleteClasses.js [app-ssr] (ecmascript) <export default as autocompleteClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/css.ts [app-ssr] (ecmascript)");
;
;
;
;
function autocomplete(theme) {
    return {
        MuiAutocomplete: {
            styleOverrides: {
                root: {
                    [`& span.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$autocompleteClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__autocompleteClasses$3e$__["autocompleteClasses"].tag}`]: {
                        ...theme.typography.subtitle2,
                        height: 24,
                        minWidth: 24,
                        lineHeight: '24px',
                        textAlign: 'center',
                        padding: theme.spacing(0, 0.75),
                        color: theme.palette.text.secondary,
                        borderRadius: theme.shape.borderRadius,
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.16)
                    }
                },
                paper: {
                    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paper"])({
                        theme,
                        dropdown: true
                    })
                },
                listbox: {
                    padding: 0,
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$autocompleteClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__autocompleteClasses$3e$__["autocompleteClasses"].option}`]: {
                        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$css$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["menuItem"])(theme)
                    }
                },
                endAdornment: {
                    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$svgIconClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__svgIconClasses$3e$__["svgIconClasses"].root}`]: {
                        width: 18,
                        height: 18
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/toggle-button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toggleButton",
    ()=>toggleButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$toggleButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toggleButtonClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButton/toggleButtonClasses.js [app-ssr] (ecmascript) <export default as toggleButtonClasses>");
;
;
// ----------------------------------------------------------------------
const COLORS = [
    'primary',
    'secondary',
    'info',
    'success',
    'warning',
    'error'
];
function toggleButton(theme) {
    const rootStyles = (ownerState)=>{
        const defaultStyle = {
            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$toggleButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toggleButtonClasses$3e$__["toggleButtonClasses"].selected}`]: {
                borderColor: 'currentColor',
                boxShadow: '0 0 0 0.5px currentColor'
            }
        };
        const colorStyle = COLORS.map((color)=>({
                ...ownerState.color === color && {
                    '&:hover': {
                        borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, 0.48),
                        backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette[color].main, theme.palette.action.hoverOpacity)
                    }
                }
            }));
        const disabledState = {
            [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$toggleButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toggleButtonClasses$3e$__["toggleButtonClasses"].disabled}`]: {
                [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$toggleButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toggleButtonClasses$3e$__["toggleButtonClasses"].selected}`]: {
                    color: theme.palette.action.disabled,
                    backgroundColor: theme.palette.action.selected,
                    borderColor: theme.palette.action.disabledBackground
                }
            }
        };
        return [
            defaultStyle,
            ...colorStyle,
            disabledState
        ];
    };
    return {
        MuiToggleButton: {
            styleOverrides: {
                root: ({ ownerState })=>rootStyles(ownerState)
            }
        },
        MuiToggleButtonGroup: {
            styleOverrides: {
                root: {
                    borderRadius: theme.shape.borderRadius,
                    backgroundColor: theme.palette.background.paper,
                    border: `solid 1px ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.grey[500], 0.08)}`
                },
                grouped: {
                    margin: 4,
                    [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$toggleButtonClasses$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toggleButtonClasses$3e$__["toggleButtonClasses"].selected}`]: {
                        boxShadow: 'none'
                    },
                    '&:not(:first-of-type), &:not(:last-of-type)': {
                        borderRadius: theme.shape.borderRadius,
                        borderColor: 'transparent'
                    }
                }
            }
        }
    };
}
}),
"[project]/src/theme/overrides/components/loading-button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadingButton",
    ()=>loadingButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$lab$2f$esm$2f$LoadingButton$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/lab/esm/LoadingButton/index.js [app-ssr] (ecmascript)");
;
function loadingButton(theme) {
    return {
        MuiLoadingButton: {
            styleOverrides: {
                root: ({ ownerState })=>({
                        ...ownerState.variant === 'soft' && {
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$lab$2f$esm$2f$LoadingButton$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadingButtonClasses"].loadingIndicatorStart}`]: {
                                left: 10
                            },
                            [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$lab$2f$esm$2f$LoadingButton$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadingButtonClasses"].loadingIndicatorEnd}`]: {
                                right: 14
                            },
                            ...ownerState.size === 'small' && {
                                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$lab$2f$esm$2f$LoadingButton$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadingButtonClasses"].loadingIndicatorStart}`]: {
                                    left: 10
                                },
                                [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$lab$2f$esm$2f$LoadingButton$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadingButtonClasses"].loadingIndicatorEnd}`]: {
                                    right: 10
                                }
                            }
                        }
                    })
            }
        }
    };
}
}),
"[project]/src/theme/overrides/index.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "componentsOverrides",
    ()=>componentsOverrides
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$merge$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash.merge/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$fab$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/fab.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$chip$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/chip.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/tabs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/menu.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$list$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/list.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/table.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$alert$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/alert.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/badge.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$paper$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/paper.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$radio$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/radio.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$appbar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/appbar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$drawer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/drawer.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/avatar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$rating$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/rating.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$slider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/slider.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/select.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$default$2d$props$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/default-props.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$switch$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/switch.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$tooltip$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/tooltip.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$popover$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/popover.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$stepper$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/stepper.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$svg$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/svg-icon.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/skeleton.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$backdrop$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/backdrop.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$progress$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/progress.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$timeline$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/timeline.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/checkbox.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$data$2d$grid$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/data-grid.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$tree$2d$view$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/tree-view.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$textfield$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/textfield.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/accordion.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$typography$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/typography.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$pagination$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/pagination.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$date$2d$picker$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/date-picker.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$breadcrumbs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/breadcrumbs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$css$2d$baseline$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/css-baseline.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$button$2d$group$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/button-group.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$autocomplete$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/autocomplete.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$toggle$2d$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/toggle-button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$loading$2d$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/components/loading-button.tsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function componentsOverrides(theme) {
    const components = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$merge$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$default$2d$props$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultProps"])(theme), //
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$fab$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fab"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tabs"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$chip$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["chip"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["card"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$menu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["menu"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$list$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["list"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$badge$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["badge"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$table$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["table"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$paper$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paper"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$alert$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alert"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$radio$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["radio"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["select"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["button"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$rating$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rating"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dialog"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$appbar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["appBar"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$avatar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["avatar"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$slider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["slider"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$drawer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawer"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$stepper$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stepper"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$tooltip$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tooltip"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$popover$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["popover"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$svg$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["svgIcon"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$switch$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["switches"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["checkbox"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$data$2d$grid$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataGrid"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$skeleton$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["skeleton"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$timeline$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["timeline"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$tree$2d$view$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["treeView"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$backdrop$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["backdrop"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$progress$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["progress"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$textfield$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["textField"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$accordion$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["accordion"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$typography$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["typography"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$pagination$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["pagination"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$date$2d$picker$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["datePicker"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$button$2d$group$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonGroup"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$breadcrumbs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["breadcrumbs"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$css$2d$baseline$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cssBaseline"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$autocomplete$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["autocomplete"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$toggle$2d$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toggleButton"])(theme), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$components$2f$loading$2d$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadingButton"])(theme));
    return components;
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/theme/next-emotion-cache.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NextAppDirEmotionCacheProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$cache$2f$dist$2f$emotion$2d$cache$2e$development$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@emotion/cache/dist/emotion-cache.development.esm.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$react$2f$dist$2f$emotion$2d$element$2d$782f682d$2e$development$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__C__as__CacheProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/@emotion/react/dist/emotion-element-782f682d.development.esm.js [app-ssr] (ecmascript) <export C as CacheProvider>");
"use client";
;
;
;
;
;
function NextAppDirEmotionCacheProvider(props) {
    const { options, CacheProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$react$2f$dist$2f$emotion$2d$element$2d$782f682d$2e$development$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__C__as__CacheProvider$3e$__["CacheProvider"], children } = props;
    const [registry] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"](()=>{
        const cache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$cache$2f$dist$2f$emotion$2d$cache$2e$development$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(options);
        cache.compat = true;
        const prevInsert = cache.insert;
        let inserted = [];
        cache.insert = (...args)=>{
            const [selector, serialized] = args;
            if (cache.inserted[serialized.name] === undefined) {
                inserted.push({
                    name: serialized.name,
                    isGlobal: !selector
                });
            }
            return prevInsert(...args);
        };
        const flush = ()=>{
            const prevInserted = inserted;
            inserted = [];
            return prevInserted;
        };
        return {
            cache,
            flush
        };
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useServerInsertedHTML"])(()=>{
        const inserted = registry.flush();
        if (inserted.length === 0) {
            return null;
        }
        let styles = "";
        let dataEmotionAttribute = registry.cache.key;
        const globals = [];
        inserted.forEach(({ name, isGlobal })=>{
            const style = registry.cache.inserted[name];
            if (typeof style !== "boolean") {
                if (isGlobal) {
                    globals.push({
                        name,
                        style: style ?? ""
                    });
                } else {
                    styles += style;
                    dataEmotionAttribute += ` ${name}`;
                }
            }
        });
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                globals.map(({ name, style })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                        "data-emotion": `${registry.cache.key}-global ${name}`,
                        // eslint-disable-next-line react/no-danger
                        dangerouslySetInnerHTML: {
                            __html: style
                        }
                    }, name, false, {
                        fileName: "[project]/src/theme/next-emotion-cache.tsx",
                        lineNumber: 83,
                        columnNumber: 11
                    }, this)),
                styles && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                    "data-emotion": dataEmotionAttribute,
                    // eslint-disable-next-line react/no-danger
                    dangerouslySetInnerHTML: {
                        __html: styles
                    }
                }, void 0, false, {
                    fileName: "[project]/src/theme/next-emotion-cache.tsx",
                    lineNumber: 91,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true);
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CacheProvider, {
        value: registry.cache,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/theme/next-emotion-cache.tsx",
        lineNumber: 101,
        columnNumber: 10
    }, this);
}
}),
"[project]/src/theme/index.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/theme/index.tsx
__turbopack_context__.s([
    "default",
    ()=>ThemeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CssBaseline$2f$CssBaseline$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CssBaseline/CssBaseline.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/createTheme.js [app-ssr] (ecmascript) <export default as createTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ThemeProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProvider.js [app-ssr] (ecmascript) <export default as ThemeProvider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/palette.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$shadows$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/shadows.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$typography$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/theme/typography.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$custom$2d$shadows$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/custom-shadows.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/overrides/index.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$next$2d$emotion$2d$cache$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/theme/next-emotion-cache.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function ThemeProvider({ children }) {
    const memoizedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            palette: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$palette$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["palette"])("light"),
            shadows: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$shadows$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["shadows"])("light"),
            customShadows: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$custom$2d$shadows$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["customShadows"])("light"),
            shape: {
                borderRadius: 8
            },
            typography: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$typography$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["typography"]
        }), []);
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__["createTheme"])(memoizedValue);
    theme.components = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$overrides$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["componentsOverrides"])(theme);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$theme$2f$next$2d$emotion$2d$cache$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        options: {
            key: "css"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProvider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ThemeProvider$3e$__["ThemeProvider"], {
            theme: theme,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CssBaseline$2f$CssBaseline$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/theme/index.tsx",
                    lineNumber: 42,
                    columnNumber: 9
                }, this),
                children
            ]
        }, void 0, true, {
            fileName: "[project]/src/theme/index.tsx",
            lineNumber: 41,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/theme/index.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/dynamic-access-async-storage.external.js [external] (next/dist/server/app-render/dynamic-access-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/dynamic-access-async-storage.external.js", () => require("next/dist/server/app-render/dynamic-access-async-storage.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0350a112._.js.map