(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_2966ba18._.js",
  "static/chunks/src_app_auth_login_page_tsx_f6e4585f._.js"
],
    source: "dynamic"
});
