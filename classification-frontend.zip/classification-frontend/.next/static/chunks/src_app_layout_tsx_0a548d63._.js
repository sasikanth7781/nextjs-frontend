(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__b14e71e8._.css",
  "static/chunks/[root-of-the-server]__92e2f0a5._.js",
  "static/chunks/node_modules_f155c45a._.js"
],
    source: "dynamic"
});
